#include <linux/timex.h>
#include <asm/unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

extern long syscall(long number, ...);

int main(void) {
    /* Wait until the parent has installed the isolated filters and enabled tracing. */
    if (getchar() == EOF) return 2;
    struct __kernel_timex tx;
    memset(&tx, 0, sizeof(tx));
    tx.modes = 0;                 /* query only: no ADJ_* mode bits */
    tx.tick = 0x12345678;         /* ignored as setter input because modes=0 */
    errno = 0;
    long state = syscall(__NR_adjtimex, &tx);
    int saved_errno = errno;
    printf("syscall=adjtimex initial_modes=0 initial_tick=%lld return_state=%ld errno=%d output_tick=%lld\n",
           (long long)0x12345678, state, saved_errno, (long long)tx.tick);
    return state < 0 ? 1 : 0;
}
