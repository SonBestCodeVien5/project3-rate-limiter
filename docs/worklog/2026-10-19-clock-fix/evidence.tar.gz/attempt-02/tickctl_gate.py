#!/usr/bin/env python3
"""Hold the setter process for PID/NSpid mapping, then exec the audited tickctl."""
import os, pathlib, sys
ctl='/home/khanhson2005/projects/project3-rate-limiter/artifacts/tick-trial-20261019-0417-dd307a6/tickctl'
if len(sys.argv)!=3: raise SystemExit('usage: tickctl_gate.py EXPECTED TARGET')
if sys.stdin.buffer.read(1)!=b'x': raise SystemExit('parent did not release setter')
os.execv(ctl,[ctl,'set-tick',sys.argv[1],sys.argv[2]])
