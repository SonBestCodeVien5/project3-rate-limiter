#define _GNU_SOURCE
#include <stddef.h>
#include <stdio.h>
#include <sys/utsname.h>
#include <linux/timex.h>

int main(void) {
#if !defined(__x86_64__)
#error This probe is restricted to native x86_64 ABI
#endif
    struct utsname u;
    if (uname(&u) != 0) return 2;
    printf("uname_release=%s\n", u.release);
    printf("machine=%s\n", u.machine);
    printf("pointer_size=%zu\n", sizeof(void *));
    printf("header=/usr/include/linux/timex.h\n");
    printf("sizeof_struct___kernel_timex=%zu\n", sizeof(struct __kernel_timex));
    printf("modes_offset=%zu modes_size=%zu\n", offsetof(struct __kernel_timex, modes), sizeof(((struct __kernel_timex *)0)->modes));
    printf("tick_offset=%zu tick_size=%zu\n", offsetof(struct __kernel_timex, tick), sizeof(((struct __kernel_timex *)0)->tick));
    return 0;
}
