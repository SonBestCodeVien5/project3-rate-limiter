import subprocess,pathlib,json
out=pathlib.Path(__file__).resolve().parent
src=out/'sentinel_query.c'
p=subprocess.run(['gcc','-std=c11','-m64','-O2','-Wall','-Wextra','-Werror',str(src),'-o',str(out/'sentinel_query')],capture_output=True,text=True,timeout=8)
result={'argv':p.args,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(out/'compile-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(p.returncode)
