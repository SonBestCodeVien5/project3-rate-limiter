import importlib.util, pathlib, tempfile, os, re, json
base=pathlib.Path(__file__).resolve().parent
script=base/'run_attribution.py'
src=script.read_text()
spec=importlib.util.spec_from_file_location('trace_attempt',script)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
checks={}
# Append-only behavior with unrelated pre-existing entries preserved.
with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td)/'kprobe_events'
 original='p:unrelated_group/sentinel do_not_touch arg=+0($arg1):x64\np:other_group/other other_symbol\n'
 p.write_text(original)
 fd=os.open(p,os.O_WRONLY|os.O_APPEND)
 try:os.write(fd,(mod.ENTRY_PROBE+'\n').encode());os.write(fd,(mod.RET_PROBE+'\n').encode())
 finally:os.close(fd)
 data=p.read_text()
 assert data.startswith(original) and 'unrelated_group/sentinel' in data and 'other_group/other' in data and mod.GROUP+'/adj_tick_ret' in data
 checks['append_preserves_existing_and_unrelated']=True
# Standard grouped and ungrouped trace text, with caller PID and return pairing.
fixture=(f'sentinel_query-431 [000] .... 12.003: {mod.GROUP}:{mod.ENTRY}: modes=0x00000000 tick=305419896\n'
         f'sentinel_query-431 [000] .... 12.004: {mod.GROUP}:{mod.RET}: retval=0\n'
         f'tickctl-432 [001] .... 12.103: {mod.ENTRY}: modes=0x00004000 tick=10000\n'
         f'tickctl-432 [001] .... 12.104: {mod.RET}: retval=0\n')
events=mod.parse_events(fixture); pairs=mod.pair_adj_tick_events(events)
assert len(events)==4 and len(pairs)==1 and pairs[0]['entry']['pid']==432 and pairs[0]['entry']['modes']==16384 and pairs[0]['entry']['tick']==10000 and pairs[0]['return']['retval']==0 and pairs[0]['return_success']
checks['grouped_ungrouped_parser_and_return_pairing']=True
# Sentinel waits for parent release; no syscall before the byte.
c=(base/'sentinel_query.c').read_text(); assert c.index('getchar()') < c.index('syscall(__NR_adjtimex')
assert src.index("write(entry_en,'1'); write(ret_en,'1'); write(INST/'tracing_on','1')") < src.index("sentinel_p.communicate(input='x'")
checks['sentinel_handshake_prevents_early_query']=True
# Kprobe registration/deletion are O_APPEND-only; exact before/after audit is present.
assert 'os.O_WRONLY|os.O_APPEND' in src and 'write(KPROBES' not in src and "append_kprobe(f'-:{GROUP}/{nm}')" in src
assert "(OUT/'kprobe-events-before.txt').write_text" in src and "(OUT/'kprobe-events-after.txt').write_text" in src
checks['kprobe_append_and_audit_only']=True
# Each attempt has fresh, distinct marker paths and current ones are absent.
assert mod.OUT.name=='attempt-02' and not mod.ARM.exists() and not mod.DISARM.exists() and not mod.INTENT.exists() and not mod.GUARD_RESULT.exists()
assert mod.GROUP not in 'clockfix_20261019_1205'
checks['fresh_attempt_markers_and_unique_names']=True
(base/'local-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
