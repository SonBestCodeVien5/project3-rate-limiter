#!/usr/bin/env python3
"""Validate numeric UAPI fetches, then one guarded tick trial under isolated tracefs."""
import json, os, pathlib, re, signal, subprocess, sys, threading, time

OUT=pathlib.Path(__file__).resolve().parent
TRACE=pathlib.Path('/sys/kernel/tracing')
INST=TRACE/'instances'/'clockfix_20261019_1220a'
GROUP='clockfix_20261019_1220a'
ENTRY='adj_tick'
RET='adj_tick_ret'
KPROBES=TRACE/'kprobe_events'
ENTRY_PROBE=f'p:{GROUP}/{ENTRY} do_adjtimex modes=+0($arg1):x32 tick=+88($arg1):s64'
RET_PROBE=f'r:{GROUP}/{RET} do_adjtimex retval=$retval:s64'
CTL=pathlib.Path('/home/khanhson2005/projects/project3-rate-limiter/artifacts/tick-trial-20261019-0417-dd307a6/tickctl')
SENTINEL=OUT/'sentinel_query'
MAX_ACTIVE_RAW=35.0
GUARD_RAW=37.0
SENTINEL_VALUE=0x12345678
ARM=OUT/'watchdog-arm.json'; DISARM=OUT/'watchdog-disarm.json'; INTENT=OUT/'setter-attempt.json'; GUARD_RESULT=OUT/'watchdog-result.json'; GUARD_LOG=OUT/'watchdog.log'
signal.signal(signal.SIGTERM,lambda s,f: (_ for _ in ()).throw(InterruptedError('SIGTERM')))
signal.signal(signal.SIGINT,lambda s,f: (_ for _ in ()).throw(InterruptedError('SIGINT')))

def raw_ns(): return time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
def write(path,value):
    with path.open('w') as f: f.write(str(value))
def append_kprobe(value):
    fd=os.open(KPROBES,os.O_WRONLY|os.O_APPEND)
    try: os.write(fd,(str(value)+'\n').encode())
    finally: os.close(fd)
def read(path): return path.read_text(errors='replace')
def run(args,timeout=3):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        return {'argv':args,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    except Exception as e:return {'argv':args,'error':type(e).__name__+': '+str(e)}
def tick_query(): return run([str(CTL),'query'],2)
def proc_ids(pid):
    out={'pid_native':pid}
    try:
        for line in (pathlib.Path('/proc')/str(pid)/'status').read_text().splitlines():
            if line.startswith(('Pid:','Tgid:','NSpid:')):
                key,val=line.split(':',1); out[key.strip()]=[int(x) for x in val.split()] if key=='NSpid' else int(val.strip())
    except OSError as e: out['status_error']=str(e)
    return out

def set_tick(old,new):
    try:
        p=subprocess.Popen([sys.executable,str(OUT/'tickctl_gate.py'),str(old),str(new)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        ids=proc_ids(p.pid)
        out,err=p.communicate(input='x',timeout=4)
        return {'argv':['tickctl_gate.py',str(old),str(new)],'returncode':p.returncode,'pid_namespace':ids,'stdout':out,'stderr':err}
    except Exception as e:return {'argv':['tickctl_gate.py',str(old),str(new)],'error':type(e).__name__+': '+str(e)}
def parse_header_pid(line):
    m=re.match(r'^\s*(.*?)-(\d+)\s+\[',line)
    return (m.group(1),int(m.group(2))) if m else (None,None)
def parse_events(text):
    events=[]
    entry_mark=re.compile(r'(?:'+re.escape(GROUP)+r'[:/])?'+re.escape(ENTRY)+r':')
    ret_mark=re.compile(r'(?:'+re.escape(GROUP)+r'[:/])?'+re.escape(RET)+r':')
    for line in text.splitlines():
        if entry_mark.search(line):
            comm,pid=parse_header_pid(line)
            m=re.search(r'\bmodes=(0x[0-9a-fA-F]+|[0-9]+)',line)
            t=re.search(r'\btick=(-?[0-9]+)',line)
            events.append({'kind':'entry','pid':pid,'comm':comm,'modes':int(m.group(1),0) if m else None,'tick':int(t.group(1)) if t else None,'line':line})
        elif ret_mark.search(line):
            comm,pid=parse_header_pid(line)
            m=re.search(r'\bretval=(-?[0-9]+)',line)
            events.append({'kind':'return','pid':pid,'comm':comm,'retval':int(m.group(1)) if m else None,'line':line})
    return events
def pair_adj_tick_events(events):
    pairs=[]
    for i,e in enumerate(events):
        if e.get('kind')=='entry' and e.get('modes') is not None and e['modes']&16384:
            ret=next((x for x in events[i+1:] if x.get('kind')=='return' and x.get('pid')==e.get('pid')),None)
            pairs.append({'entry':e,'return':ret,'return_success':ret is not None and ret.get('retval') is not None and ret['retval']>=0})
    return pairs

def process_meta(pid):
    p=pathlib.Path('/proc')/str(pid); item={'pid':pid}
    try:item['comm']=(p/'comm').read_text().strip()
    except OSError:item['comm']='exited_before_snapshot'
    try:
        for ln in (p/'status').read_text().splitlines():
            if ln.startswith('PPid:'):item['ppid']=int(ln.split()[1])
            elif ln.startswith('NSpid:'):item['nspid']=[int(x) for x in ln.split(':',1)[1].split()]
            elif ln.startswith(('Pid:','Tgid:')):item[ln.split(':',1)[0].lower()]=int(ln.split()[1])
    except OSError:pass
    try:item['exe']=os.path.basename(os.readlink(p/'exe'))
    except OSError:item['exe']='unavailable_or_exited'
    try:item['cgroup']=[ln for ln in (p/'cgroup').read_text().splitlines() if ln][:8]
    except OSError:pass
    parent=item.get('ppid')
    if parent and parent>0:
        pp=pathlib.Path('/proc')/str(parent); parent_item={'pid':parent}
        try:parent_item['comm']=(pp/'comm').read_text().strip()
        except OSError:parent_item['comm']='exited_before_snapshot'
        try:parent_item['exe']=os.path.basename(os.readlink(pp/'exe'))
        except OSError:parent_item['exe']='unavailable_or_exited'
        try:parent_item['cgroup']=[ln for ln in (pp/'cgroup').read_text().splitlines() if ln][:4]
        except OSError:pass
        item['parent']=parent_item
    return item

def watchdog():
    start=raw_ns()
    while not ARM.exists() and not DISARM.exists() and raw_ns()-start<10_000_000_000:time.sleep(.05)
    if DISARM.exists() or not ARM.exists():
        (GUARD_RESULT).write_text(json.dumps({'result':'disarmed_before_arm_or_no_arm','raw_ns':raw_ns()},indent=2)+'\n');return 0
    arm=json.loads(ARM.read_text()); deadline=arm['arm_raw_ns']+int(GUARD_RAW*1e9)
    while not DISARM.exists() and raw_ns()<deadline:time.sleep(.05)
    if DISARM.exists():
        state={'result':'main_disarmed_after_verified_restore','raw_ns':raw_ns()}
    elif not INTENT.exists():
        state={'result':'no_setter_attempt_recorded; no clock restoration issued','raw_ns':raw_ns()}
    else:
        q=tick_query(); text=q.get('stdout','')
        if q.get('returncode')==0 and 'tick_us=10000' in text:
            s=set_tick(10000,9167); verify=tick_query()
            state={'result':'watchdog_restore_attempted','raw_ns':raw_ns(),'query':q,'setter':s,'verification':verify,'verified':'tick_us=9167' in verify.get('stdout','')}
        else: state={'result':'watchdog_found_not_trial_value_or_query_failed','raw_ns':raw_ns(),'query':q}
    GUARD_RESULT.write_text(json.dumps(state,indent=2)+'\n')
    return 0 if state['result']=='main_disarmed_after_verified_restore' or state.get('verified') or state['result']=='watchdog_found_not_trial_value_or_query_failed' else 10

def main():
    result={'revision':'4efefc306e84d8f1f17826dfb52183f3a52e452a','kernel_probe':ENTRY_PROBE,'return_probe':RET_PROBE,'offset_source':'runtime-validated x86_64 linux-libc-dev UAPI offsetof query; modes=0 size4 offset0, tick size8 offset88','sentinel_input':SENTINEL_VALUE,'active_max_raw_seconds':MAX_ACTIVE_RAW,'watchdog_raw_seconds':GUARD_RAW}
    if os.geteuid()!=0: raise RuntimeError('native process not root')
    if not TRACE.is_dir() or not (TRACE/'instances').is_dir() or not KPROBES.exists(): raise RuntimeError('tracefs/kprobe support unavailable')
    if INST.exists(): raise RuntimeError('unique trace instance already exists')
    result['global_before']={'tracing_on':read(TRACE/'tracing_on').strip(),'current_tracer':read(TRACE/'current_tracer').strip()}
    result['tick_before']=tick_query()
    if result['tick_before'].get('returncode')!=0 or 'tick_us=9167' not in result['tick_before'].get('stdout','') or 'freq_scaled_ppm=-2201602' not in result['tick_before'].get('stdout',''):
        result.update(status='aborted_precondition',reason='expected tick=9167 and original freq=-2201602; no trace configuration or setter attempted')
        (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print('CLOCK_TRACE_ABORT '+json.dumps(result,sort_keys=True),flush=True)
        return 20
    created=False; setter_attempted=False; registered=[]; guardian=None; started=None; trace_txt=''; failure=None; active_samples=[]; tick_polls=[]; sentinel_out=None; sentinel_events=[]; sentinel_p=None; before_kprobes=None
    try:
        before_kprobes=read(KPROBES)
        (OUT/'kprobe-events-before.txt').write_text(before_kprobes)
        if f'{GROUP}/{ENTRY}' in before_kprobes or f'{GROUP}/{RET}' in before_kprobes: raise RuntimeError('unique kprobe names already present; refusing to reuse')
        # Append only unique definitions; never open the global tracefs control with truncation.
        registered.append(ENTRY); append_kprobe(ENTRY_PROBE)
        registered.append(RET); append_kprobe(RET_PROBE)
        entry_fmt=read(TRACE/'events'/GROUP/ENTRY/'format'); ret_fmt=read(TRACE/'events'/GROUP/RET/'format')
        (OUT/'entry-event-format.txt').write_text(entry_fmt); (OUT/'return-event-format.txt').write_text(ret_fmt)
        for fld in ('modes','tick','common_pid'):
            if fld not in entry_fmt: raise RuntimeError('entry format lacks '+fld)
        for fld in ('retval','common_pid'):
            if fld not in ret_fmt: raise RuntimeError('return format lacks '+fld)
        result['entry_format_validated']=True; result['return_format_validated']=True
        INST.mkdir(); created=True
        write(INST/'buffer_size_kb','64')
        entry_en=INST/'events'/GROUP/ENTRY/'enable'; entry_filter=INST/'events'/GROUP/ENTRY/'filter'
        ret_en=INST/'events'/GROUP/RET/'enable'; ret_filter=INST/'events'/GROUP/RET/'filter'
        if not all(p.exists() for p in (entry_en,entry_filter,ret_en,ret_filter)): raise RuntimeError('per-instance kprobe controls absent after global registration and instance creation')
        sentinel_p=subprocess.Popen([str(SENTINEL)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        sentinel_pid=sentinel_p.pid
        f=f'modes == 0 && tick == {SENTINEL_VALUE}'
        write(entry_filter,f); entry_filter_rb=read(entry_filter).strip()
        rf='0'
        write(ret_filter,rf); ret_filter_rb=read(ret_filter).strip()
        if 'modes' not in entry_filter_rb or 'tick' not in entry_filter_rb or str(SENTINEL_VALUE) not in entry_filter_rb: raise RuntimeError('sentinel event filter readback failed')
        result['sentinel_native_pid_namespace']=proc_ids(sentinel_pid)
        write(entry_en,'1'); write(ret_en,'1'); write(INST/'tracing_on','1')
        so,se=sentinel_p.communicate(input='x',timeout=3); sentinel_out={'pid':sentinel_pid,'returncode':sentinel_p.returncode,'stdout':so,'stderr':se}
        time.sleep(.05)
        write(INST/'tracing_on','0')
        trace_txt=read(INST/'trace'); (OUT/'sentinel-trace.txt').write_text(trace_txt)
        sentinel_events=parse_events(trace_txt)
        result['sentinel_result']=sentinel_out; result['sentinel_events']=sentinel_events
        valid=sentinel_p.returncode==0 and 'initial_modes=0' in so and f'initial_tick={SENTINEL_VALUE}' in so and 'output_tick=9167' in so
        entries=[e for e in sentinel_events if e['kind']=='entry']
        returns=[e for e in sentinel_events if e['kind']=='return']
        sentinel_kernel_pid=entries[0]['pid'] if len(entries)==1 else None
        result['sentinel_kernel_tid']=sentinel_kernel_pid
        result['sentinel_pid_namespace_match']=sentinel_kernel_pid in result.get('sentinel_native_pid_namespace',{}).get('NSpid',[])
        valid=valid and len(entries)==1 and entries[0]['modes']==0 and entries[0]['tick']==SENTINEL_VALUE and any(e['pid']==sentinel_kernel_pid and e['retval'] is not None and e['retval']>=0 for e in returns)
        result['sentinel_runtime_layout_validated']=bool(valid)
        if not valid: raise RuntimeError('runtime sentinel did not validate query field offsets/return; no tick trial started')
        # Clear only this isolated instance buffer, then apply the ADJ_TICK filter.
        write(entry_en,'0'); write(ret_en,'0'); write(INST/'trace','0')
        write(entry_filter,'modes & 16384'); result['setter_filter']=read(entry_filter).strip()
        write(ret_filter,'0')
        if 'modes' not in result['setter_filter'] or '16384' not in result['setter_filter']: raise RuntimeError('ADJ_TICK filter readback failed')
        # Start the independent RAW-clock restoration guard before any setter.
        with GUARD_LOG.open('w') as log:
            guardian=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).resolve()),'--watchdog'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        time.sleep(.05)
        if guardian.poll() is not None: raise RuntimeError('rollback watchdog failed to start')
        write(entry_en,'1'); write(ret_en,'1'); write(INST/'tracing_on','1')
        arm_raw=raw_ns(); ARM.write_text(json.dumps({'arm_raw_ns':arm_raw,'original_tick':9167,'trial_tick':10000,'guardian_pid':guardian.pid},indent=2)+'\n')
        INTENT.write_text(json.dumps({'attempt_raw_ns':raw_ns(),'expected_before_tick':9167,'target_tick':10000},indent=2)+'\n'); setter_attempted=True
        setter=set_tick(9167,10000); result['trial_setter']=setter; result['setter_raw_ns']=raw_ns()
        if setter.get('returncode')!=0 or 'tick_us=10000' not in setter.get('stdout',''):
            result['trial_setter_verified']=False
            failure='trial tick setter did not immediately read back 10000; no active window continued'
        else:
            result['trial_setter_verified']=True
            result['trial_setter_pid_namespace']=setter.get('pid_namespace')
            started=raw_ns(); deadline=started+int(MAX_ACTIVE_RAW*1e9); next_tick=started; next_trace_poll=started; seen_entries=set(); live_writer_events=[]
            while raw_ns()<deadline:
                m1=time.monotonic_ns(); r1=raw_ns(); wall=time.time_ns(); r2=raw_ns(); m2=time.monotonic_ns()
                active_samples.append({'elapsed_raw_s':(r1-started)/1e9,'raw_ns':(r1+r2)//2,'monotonic_ns':(m1+m2)//2,'wall_ns':wall,'span_mono_ns':m2-m1})
                now=raw_ns()
                if now>=next_tick:
                    tick_polls.append({'raw_ns':now,'query':tick_query()}); next_tick+=500_000_000
                if now>=next_trace_poll:
                    snapshot=read(INST/'trace')
                    live_events=parse_events(snapshot)
                    for pair in pair_adj_tick_events(live_events):
                        ent=pair['entry']; key=ent.get('line')
                        if key in seen_entries: continue
                        seen_entries.add(key)
                        entry_meta=process_meta(ent['pid']) if ent.get('pid') is not None else {'pid':None,'lookup':'trace PID absent'}
                        own_ids=set((result.get('trial_setter_pid_namespace') or {}).get('NSpid',[]))
                        is_own=ent.get('pid') in own_ids
                        evidence={'entry':{k:ent.get(k) for k in ('pid','comm','modes','tick')},'return':{k:pair['return'].get(k) for k in ('pid','comm','retval')} if pair.get('return') else None,'return_success':pair['return_success'],'is_our_setter':is_own,'process_metadata_at_first_poll':entry_meta,'seen_raw_ns':now}
                        live_writer_events.append(evidence)
                        if not is_own:
                            print('EXTERNAL_ADJ_TICK '+json.dumps(evidence,sort_keys=True),flush=True)
                    result['live_writer_events']=live_writer_events
                    next_trace_poll=now+100_000_000
                time.sleep(.05)
    except BaseException as e:
        failure=f'{type(e).__name__}: {e}'
    finally:
        if INST.exists():
            try: write(INST/'tracing_on','0')
            except Exception as e: result['trace_stop_error']=repr(e)
            try:
                trace_txt=read(INST/'trace'); (OUT/'trial-trace.txt').write_text(trace_txt)
            except Exception as e: result['trace_read_error']=repr(e)
        # Restore only if our trial value is still present; never overwrite a third-party value.
        final_pre=tick_query(); result['pre_restore_query']=final_pre
        restore=None
        if setter_attempted and 'tick_us=10000' in final_pre.get('stdout',''):
            restore=set_tick(10000,9167); result['own_restore_setter']=restore
        elif setter_attempted and 'tick_us=9167' in final_pre.get('stdout',''):
            restore={'returncode':0,'stdout':'external path already returned tick to original 9167; own restore skipped','stderr':''}; result['own_restore_setter']=restore
        elif setter_attempted:
            restore={'returncode':None,'stdout':'unexpected tick value; did not overwrite','stderr':''}; result['own_restore_setter']=restore
        else:
            restore={'returncode':None,'stdout':'no trial setter was invoked; no restoration write attempted','stderr':''}; result['own_restore_setter']=restore
        result['tick_final_query']=tick_query()
        result['restored_verified']='tick_us=9167' in result['tick_final_query'].get('stdout','')
        if result['restored_verified']:
            DISARM.write_text(json.dumps({'verified_original_tick':9167,'raw_ns':raw_ns()},indent=2)+'\n')
        if INST.exists():
            for nm in (ENTRY,RET):
                try:
                    en=INST/'events'/GROUP/nm/'enable'
                    if en.exists(): write(en,'0')
                except Exception as e: result.setdefault('event_disable_errors',[]).append({nm:repr(e)})
        for nm in reversed(registered):
            try:
                append_kprobe(f'-:{GROUP}/{nm}')
                result.setdefault('unregistered',[]).append(nm)
            except Exception as e: result.setdefault('unregister_errors',[]).append({nm:repr(e)})
        try:
            after_kprobes=read(KPROBES)
            (OUT/'kprobe-events-after.txt').write_text(after_kprobes)
            result['global_kprobe_definitions_restored_exactly']=before_kprobes is not None and after_kprobes==before_kprobes
        except Exception as e: result['kprobe_post_cleanup_read_error']=repr(e)
        if sentinel_p is not None and sentinel_p.poll() is None:
            sentinel_p.terminate()
            try: sentinel_p.wait(timeout=1)
            except subprocess.TimeoutExpired: sentinel_p.kill(); sentinel_p.wait(timeout=1)
            result['sentinel_cleanup']='terminated before query completion'
        if sentinel_p is not None and sentinel_p.poll() is not None: result['sentinel_returncode']=sentinel_p.returncode
        if created and INST.exists():
            try: INST.rmdir(); result['instance_removed']=True
            except Exception as e: result['instance_remove_error']=repr(e)
        if guardian is not None:
            try: guardian.wait(timeout=4)
            except subprocess.TimeoutExpired: result['guardian_timeout']=True
        result['guardian_returncode']=guardian.poll() if guardian is not None else None
        result['guardian_result']=json.loads(GUARD_RESULT.read_text()) if GUARD_RESULT.exists() else None
        result['active_duration_raw_s']=((raw_ns()-started)/1e9) if started else 0
        result['active_samples']=active_samples; result['tick_polls']=tick_polls
        result['captured_events']=parse_events(trace_txt)
        pids=sorted({e['pid'] for e in result['captured_events'] if e.get('kind')=='entry' and e.get('modes') is not None and e['modes']&16384 and e.get('pid') is not None})
        result['process_metadata']=[process_meta(pid) for pid in pids]
        # Pair each setter entry with the next return event for its TID in trace order.
        result['adj_tick_calls']=pair_adj_tick_events(result['captured_events'])
        result['failure']=failure
        try: result['global_after']={'tracing_on':read(TRACE/'tracing_on').strip(),'current_tracer':read(TRACE/'current_tracer').strip()}
        except Exception as e: result['global_after_error']=repr(e)
        result['probe_still_registered']=any(f'{GROUP}/{nm}' in read(KPROBES) for nm in (ENTRY,RET))
        result['instance_removed']=not INST.exists()
        result['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
        (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print('CLOCK_TRACE_COMPLETE '+json.dumps({k:result.get(k) for k in ('sentinel_runtime_layout_validated','sentinel_native_pid_namespace','sentinel_kernel_tid','sentinel_pid_namespace_match','sentinel_result','sentinel_events','trial_setter','trial_setter_verified','active_duration_raw_s','adj_tick_calls','process_metadata','pre_restore_query','own_restore_setter','tick_final_query','restored_verified','guardian_returncode','guardian_result','probe_still_registered','instance_removed','global_kprobe_definitions_restored_exactly','global_before','global_after','failure')},sort_keys=True),flush=True)
    return 0 if result.get('sentinel_runtime_layout_validated') and result.get('restored_verified') and result.get('instance_removed') and not result.get('probe_still_registered') else 90

if __name__=='__main__':
    if len(sys.argv)==2 and sys.argv[1]=='--watchdog': raise SystemExit(watchdog())
    raise SystemExit(main())
