import hashlib,json,pathlib,subprocess
out=pathlib.Path(__file__).resolve().parent

def run(args,timeout=5):
 try:
  p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
  return {'argv':args,'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 except Exception as e:return {'argv':args,'error':type(e).__name__+': '+str(e)}
info={}
for p in ['/usr/include/linux/timex.h']:
 q=pathlib.Path(p); info[p]={'exists':q.exists()}
 if q.exists(): info[p]['sha256']=hashlib.sha256(q.read_bytes()).hexdigest()
info['header_owner']=run(['dpkg-query','-S','/usr/include/linux/timex.h'])
info['header_package']=run(['dpkg-query','-W','-f=${Package} ${Version}\n','linux-libc-dev'])
info['compile_layout']=run(['gcc','-std=c11','-m64','-O2','-Wall','-Wextra','-Werror',str(out/'layout_probe.c'),'-o',str(out/'layout_probe')],8)
if info['compile_layout'].get('rc')==0: info['layout_result']=run([str(out/'layout_probe')])
info['compile_sentinel']=run(['gcc','-std=c11','-m64','-O2','-Wall','-Wextra','-Werror',str(out/'sentinel_query.c'),'-o',str(out/'sentinel_query')],8)
(out/'preflight.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps(info,indent=2))
