from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json, subprocess, time, sys
root=Path(__file__).resolve().parent
if any((root/name).exists() for name in ("wsl-samples.jsonl","windows-samples.jsonl","run-metadata.json","summary.json")):
    raise SystemExit("refusing to overwrite prior observation output")
ps=r"/mnt/c/WINDOWS/System32/WindowsPowerShell/v1.0/powershell.exe"
cmd=[ps,"-NoProfile","-NonInteractive","-Command",(root/"observe-windows.ps1").read_text()]
launch_wall=time.time_ns(); launch_mono=time.monotonic_ns()
try:
    win=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding="utf-8",errors="replace")
    linux=subprocess.Popen(["python3",str(root/"observe-linux.py")],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
except Exception as e:
    for p in (locals().get("win"),locals().get("linux")):
        if p and p.poll() is None: p.kill()
    raise
with ThreadPoolExecutor(max_workers=2) as pool:
    wf=pool.submit(win.communicate); lf=pool.submit(linux.communicate)
    try:
        wout,werr=wf.result(timeout=100); lout,lerr=lf.result(timeout=100)
    except Exception:
        for p in (win,linux):
            if p.poll() is None: p.kill()
        raise
(root/"windows-stdout.jsonl").write_text(wout)
(root/"windows-stderr.txt").write_text(werr)
(root/"wsl-stdout.txt").write_text(lout)
(root/"wsl-stderr.txt").write_text(lerr)
(root/"run-metadata.json").write_text(json.dumps({"revision":"a533a8062932b4f32f8a3318eaea13cbc05c170f","launch_wall_unix_ns":launch_wall,"launch_wsl_monotonic_ns":launch_mono,"windows_returncode":win.returncode,"wsl_returncode":linux.returncode,"observer_seconds":90,"sample_interval_ms":50,"step_threshold_ms":5,"bounded_subprocess_timeout_seconds":100},indent=2)+"\n")
if win.returncode or linux.returncode: raise SystemExit(f"observer failure Windows={win.returncode} WSL={linux.returncode}")
rows=[json.loads(x) for x in wout.splitlines() if x.strip()]
if not rows or rows[0].get("kind")!="metadata": raise SystemExit("missing Windows observer metadata")
(root/"windows-metadata.json").write_text(json.dumps(rows[0],indent=2)+"\n")
(root/"windows-samples.jsonl").write_text("".join(json.dumps(x,separators=(",",":"))+"\n" for x in rows[1:]))
print(json.dumps({"windows_samples":len(rows)-1,"wsl_stdout":lout.strip(),"windows_metadata":rows[0],"wallclock_started":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime(launch_wall/1e9))}))
