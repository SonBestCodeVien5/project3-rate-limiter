$ErrorActionPreference = "Stop"
$freq = [System.Diagnostics.Stopwatch]::Frequency
$high = [System.Diagnostics.Stopwatch]::IsHighResolution
$start = [System.Diagnostics.Stopwatch]::GetTimestamp()
$meta = [ordered]@{kind="metadata"; utc_start_ticks=([DateTimeOffset]::UtcNow.UtcDateTime.Ticks); stopwatch_start_ticks=$start; stopwatch_frequency=$freq; stopwatch_is_high_resolution=$high; pid=$PID}
[Console]::WriteLine((ConvertTo-Json -InputObject $meta -Compress))
$rows = New-Object 'System.Collections.Generic.List[object]'
while (($([System.Diagnostics.Stopwatch]::GetTimestamp() - $start) / [double]$freq) -lt 90.0) {
    $m1 = [System.Diagnostics.Stopwatch]::GetTimestamp()
    $utc = [DateTimeOffset]::UtcNow
    $wallNs = [long](($utc.UtcDateTime.Ticks - 621355968000000000L) * 100L)
    $m2 = [System.Diagnostics.Stopwatch]::GetTimestamp()
    $rows.Add([ordered]@{wall_unix_ns=$wallNs; stopwatch_ticks=(($m1+$m2)/2); read_span_ticks=($m2-$m1)})
    Start-Sleep -Milliseconds 50
}
foreach ($row in $rows) { [Console]::WriteLine((ConvertTo-Json -InputObject $row -Compress)) }
