# Clock source narrowing: evidence and hypotheses

## Verified local evidence

- On 2026-10-19, WSL2 `CLOCK_REALTIME` advanced 98.877 s over 90.037 s monotonic and had three adjacent-sample realtime-minus-monotonic deltas of +2.931 to +2.961 s, with ~50 ms monotonic sampling intervals. This is a guest wall-clock discontinuity relative to the guest monotonic clock; it does not identify its writer.
- WSL reports kernel `6.18.54.1-microsoft-standard-WSL2`, `tsc` current clocksource and `hyperv_clocksource_tsc_page`, `hyperv_clocksource_msr`, `acpi_pm` available. `systemd-detect-virt` says `wsl`.
- Windows `w32tm /query /status` and `/configuration` both report service not started; no matching Kernel-General/Time-Service events were found in the targeted 02:40–03:00 UTC window. This does not rule out other Windows, hypervisor, or WSL adjustment paths.

## Primary Microsoft references

- Microsoft documents Hyper-V Time Synchronization (`vmictimesync`, Linux driver `hv_utils`) as syncing the VM clock with the physical host clock: https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/integration-services
- Microsoft says integration services need host and guest enablement to function, and Linux integration drivers are generally provided through the kernel (`hv_utils`): https://learn.microsoft.com/en-us/windows-server/virtualization/hyper-v/manage/Manage-Hyper-V-integration-services
- Microsoft WSL release notes list syncing WSL2 time with host time after resume from sleep: https://learn.microsoft.com/en-us/windows/wsl/release-notes?redirectedfrom=MSDN
- Microsoft documents that Windows Time can discipline a clock by adjusting its rate or directly changing its time: https://learn.microsoft.com/en-us/windows-server/networking/windows-time-service/how-the-windows-time-service-works
- Microsoft documents `Stopwatch` as elapsed-time measurement backed by a high-resolution performance counter when supported, and exposes frequency/high-resolution status: https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.stopwatch?view=netframework-4.8

These establish plausible mechanisms only; none proves the observed steps came from W32Time, Hyper-V time sync, a WSL guest daemon, resume handling, or another actor. The paired observation tests whether Windows UTC itself steps relative to Windows Stopwatch while WSL realtime steps relative to WSL monotonic.
