import json, time, pathlib
out=pathlib.Path(__file__).resolve().parent
if not hasattr(time, "CLOCK_BOOTTIME"):
    raise SystemExit("CLOCK_BOOTTIME unavailable")
samples=[]
start=time.monotonic_ns()
while True:
    m1=time.monotonic_ns(); b1=time.clock_gettime_ns(time.CLOCK_BOOTTIME); w=time.time_ns(); b2=time.clock_gettime_ns(time.CLOCK_BOOTTIME); m2=time.monotonic_ns()
    samples.append({"wall_unix_ns":w,"monotonic_ns":(m1+m2)//2,"boottime_ns":(b1+b2)//2,"read_span_ns":m2-m1})
    if time.monotonic_ns()-start>=90_000_000_000: break
    time.sleep(.05)
(out/"wsl-samples.jsonl").write_text("".join(json.dumps(x,separators=(",",":"))+"\n" for x in samples))
print(json.dumps({"samples":len(samples),"elapsed_monotonic_seconds":(samples[-1]["monotonic_ns"]-samples[0]["monotonic_ns"])/1e9,"elapsed_boottime_seconds":(samples[-1]["boottime_ns"]-samples[0]["boottime_ns"])/1e9,"elapsed_wall_seconds":(samples[-1]["wall_unix_ns"]-samples[0]["wall_unix_ns"])/1e9,"max_read_span_us":max(x["read_span_ns"] for x in samples)/1e3}))
