#define _DEFAULT_SOURCE
#include <stdio.h>
#include <string.h>
#include <sys/timex.h>
#include <unistd.h>
int main(void) {
    struct timex tx;
    memset(&tx, 0, sizeof(tx));
    tx.modes = 0; /* adjtimex query only */
    int state = adjtimex(&tx);
    if (state < 0) { perror("adjtimex"); return 1; }
    printf("return_state=%d modes=%u tick_us=%ld freq_scaled_ppm=%ld freq_ppm=%.9f offset_us=%ld\n",
           state, tx.modes, tx.tick, tx.freq, tx.freq / 65536.0, tx.offset);
    return 0;
}
