from __future__ import annotations
import ctypes, ctypes.util, json, os, pathlib, platform, re, subprocess, threading, time

OUT = pathlib.Path(__file__).resolve().parent
DURATION_NS = 90_000_000_000
SAMPLE_NS = 50_000_000
POLL_SECONDS = 1.0
THRESHOLD_NS = 5_000_000

class Timeval(ctypes.Structure):
    _fields_ = [("tv_sec", ctypes.c_long), ("tv_usec", ctypes.c_long)]
class Timex(ctypes.Structure):
    _fields_ = [
        ("modes", ctypes.c_uint), ("offset", ctypes.c_long), ("freq", ctypes.c_long),
        ("maxerror", ctypes.c_long), ("esterror", ctypes.c_long), ("status", ctypes.c_int),
        ("constant", ctypes.c_long), ("precision", ctypes.c_long), ("tolerance", ctypes.c_long),
        ("time", Timeval), ("tick", ctypes.c_long), ("ppsfreq", ctypes.c_long),
        ("jitter", ctypes.c_long), ("shift", ctypes.c_int), ("stabil", ctypes.c_long),
        ("jitcnt", ctypes.c_long), ("calcnt", ctypes.c_long), ("errcnt", ctypes.c_long),
        ("stbcnt", ctypes.c_long), ("tai", ctypes.c_int), ("reserved", ctypes.c_int * 11),
    ]

libc = ctypes.CDLL("libc.so.6", use_errno=True)
class Timespec(ctypes.Structure):
    _fields_ = [("tv_sec", ctypes.c_long), ("tv_nsec", ctypes.c_long)]

SYS_CLOCK_GETTIME = {"x86_64": 228, "aarch64": 1139}.get(platform.machine())

def raw_clock(clock_id: int):
    if SYS_CLOCK_GETTIME is None:
        return None, "unsupported_architecture"
    ts = Timespec()
    rc = libc.syscall(ctypes.c_long(SYS_CLOCK_GETTIME), ctypes.c_int(clock_id), ctypes.byref(ts))
    if rc != 0:
        return None, f"errno_{ctypes.get_errno()}"
    return ts.tv_sec * 1_000_000_000 + ts.tv_nsec, None

def raw_adjtimex():
    if ctypes.sizeof(Timex) != 208:
        return {"available": False, "reason": f"unexpected_struct_size_{ctypes.sizeof(Timex)}"}
    tx = Timex()
    tx.modes = 0  # Query only: no ADJ_* mode bits.
    rc = libc.adjtimex(ctypes.byref(tx))
    if rc < 0:
        return {"available": False, "errno": ctypes.get_errno(), "modes": tx.modes}
    return {
        "available": True, "return_state": rc, "modes": tx.modes,
        "offset_us": tx.offset, "frequency_scaled_ppm": tx.freq,
        "frequency_ppm": tx.freq / 65536.0, "maxerror_us": tx.maxerror,
        "esterror_us": tx.esterror, "status": tx.status, "time_constant": tx.constant,
        "precision_us": tx.precision, "tolerance_ppm": tx.tolerance,
        "tick_us": tx.tick, "jitter_us": tx.jitter, "stability_scaled_ppm": tx.stabil,
        "tai": tx.tai,
    }

def run(cmd, timeout=4):
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        return {"returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    except FileNotFoundError:
        return {"unavailable": "command_not_found", "command": cmd[0]}
    except subprocess.TimeoutExpired as e:
        return {"timeout_seconds": timeout, "stdout": str(e.stdout or ""), "stderr": str(e.stderr or "")}

def selected_config():
    result = {}
    paths = [pathlib.Path("/etc/systemd/timesyncd.conf"), *sorted(pathlib.Path("/etc/systemd/timesyncd.conf.d").glob("*.conf"))]
    keys = {"NTP", "FallbackNTP", "RootDistanceMaxSec", "PollIntervalMinSec", "PollIntervalMaxSec", "ConnectionRetrySec", "SaveIntervalSec"}
    for path in paths:
        if not path.exists():
            continue
        values = []
        for line in path.read_text(errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith(("#", ";")) and "=" in line and line.split("=", 1)[0].strip() in keys:
                values.append(line)
        result[str(path)] = values
    return result

def env_and_namespace():
    preload = {k: [pathlib.Path(x).name for x in os.environ.get(k, "").split(":") if x] for k in ("LD_PRELOAD", "LD_AUDIT")}
    maps = []
    try:
        for line in pathlib.Path("/proc/self/maps").read_text().splitlines():
            if any(x in line.lower() for x in ("libfaketime", "timewarp", "libc.so", "ld-linux", "vdso", "clock")):
                maps.append(pathlib.PurePosixPath(line.split()[-1]).name if "/" in line else line.split()[-1])
    except Exception as e:
        maps = [f"unavailable:{type(e).__name__}"]
    ns = {}
    for pid in ("self", "1"):
        base = pathlib.Path(f"/proc/{pid}")
        try: ns[f"{pid}_time_namespace"] = os.readlink(base / "ns/time")
        except Exception as e: ns[f"{pid}_time_namespace"] = f"unavailable:{type(e).__name__}"
        try: ns[f"{pid}_timens_offsets"] = (base / "timens_offsets").read_text()
        except Exception as e: ns[f"{pid}_timens_offsets"] = f"unavailable:{type(e).__name__}"
    return {"ld_preload_names": preload, "mapped_clock_related_library_names": sorted(set(maps)), "time_namespace": ns}

def parse_status(raw):
    wanted = {"Server", "Poll interval", "Offset", "Packet count", "Frequency", "Jitter", "Delay", "Root distance", "Stratum", "Leap"}
    parsed = {}
    for line in raw.splitlines():
        m = re.match(r"\s*([^:]+):\s*(.*?)\s*$", line)
        if m and m.group(1) in wanted:
            parsed[m.group(1)] = m.group(2)
    return parsed

def clock_read():
    m1 = time.monotonic_ns()
    raw1 = time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
    boot1 = time.clock_gettime_ns(time.CLOCK_BOOTTIME)
    wall = time.time_ns()
    boot2 = time.clock_gettime_ns(time.CLOCK_BOOTTIME)
    raw2 = time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
    m2 = time.monotonic_ns()
    # Bypass libc clock_gettime wrappers for a second realtime and monotonic reading.
    syscall_wall, ew = raw_clock(0)
    syscall_mono, em = raw_clock(1)
    return {
        "wall_unix_ns": wall, "monotonic_ns": (m1 + m2) // 2,
        "monotonic_raw_ns": (raw1 + raw2) // 2, "boottime_ns": (boot1 + boot2) // 2,
        "read_span_monotonic_ns": m2 - m1,
        "raw_syscall_realtime_ns": syscall_wall, "raw_syscall_monotonic_ns": syscall_mono,
        "raw_syscall_errors": [x for x in (ew, em) if x],
    }

def state_snapshot(label):
    cmds = {
        "timesync_status": ["timedatectl", "timesync-status"],
        "timesync_properties": ["timedatectl", "show-timesync", "--all"],
        "service_properties": ["systemctl", "show", "systemd-timesyncd.service", "-p", "LoadState", "-p", "ActiveState", "-p", "SubState", "-p", "MainPID", "-p", "ExecMainStartTimestamp", "-p", "FragmentPath", "-p", "DropInPaths"],
    }
    return {"label": label, "captured_wall_unix_ns": time.time_ns(), "captured_monotonic_ns": time.monotonic_ns(), "adjtimex_modes0": raw_adjtimex(), "commands": {k: run(v, 4) for k, v in cmds.items()}}

if "--preflight" in os.sys.argv:
    checks = {"timex_struct_size": ctypes.sizeof(Timex), "adjtimex_modes0": raw_adjtimex(), "raw_syscalls": {str(i): raw_clock(i) for i in (0, 1, 4, 7)}, "time_namespace": env_and_namespace()}
    print(json.dumps(checks, indent=2))
    raise SystemExit(0)

if (OUT / "clock-samples.jsonl").exists():
    raise SystemExit("refusing to overwrite existing observation")
if SYS_CLOCK_GETTIME is None:
    raise SystemExit(f"unsupported raw syscall architecture {platform.machine()}")

meta = {
    "revision": "60f7dd63cddcc0fcd0889dbe961483634d9a169c",
    "observer_start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "duration_seconds": 90, "clock_sample_interval_target_ms": 50,
    "timesync_status_poll_interval_seconds": POLL_SECONDS,
    "clock_step_threshold_ms": 5, "raw_clock_gettime_syscall_number": SYS_CLOCK_GETTIME,
    "clock_info": {k: vars(time.get_clock_info(k)) for k in ("time", "monotonic", "perf_counter")},
    "environment_and_namespace": env_and_namespace(),
    "kernel_cmdline": pathlib.Path("/proc/cmdline").read_text().strip(),
    "current_clocksource": pathlib.Path("/sys/devices/system/clocksource/clocksource0/current_clocksource").read_text().strip(),
    "available_clocksources": pathlib.Path("/sys/devices/system/clocksource/clocksource0/available_clocksource").read_text().strip(),
    "systemd_version": run(["systemctl", "--version"], 4),
    "timesyncd_selected_config": selected_config(),
    "state_before": state_snapshot("before"),
}
(OUT / "observer-metadata.json").write_text(json.dumps(meta, indent=2) + "\n")

stop = threading.Event()
status_rows = []
def status_sampler():
    next_at = time.monotonic()
    while not stop.is_set():
        before_m = time.monotonic_ns(); before_w = time.time_ns()
        p = run(["timedatectl", "timesync-status"], 2)
        after_w = time.time_ns(); after_m = time.monotonic_ns()
        status_rows.append({
            "before_monotonic_ns": before_m, "after_monotonic_ns": after_m,
            "before_wall_unix_ns": before_w, "after_wall_unix_ns": after_w,
            "command": p, "parsed": parse_status(p.get("stdout", "")),
        })
        next_at += POLL_SECONDS
        stop.wait(max(0.0, next_at - time.monotonic()))

thread = threading.Thread(target=status_sampler, name="timesync-status-readonly", daemon=True)
thread.start()
samples = []
start_m = time.monotonic_ns()
start_w = time.time_ns()
try:
    while time.monotonic_ns() - start_m < DURATION_NS:
        samples.append(clock_read())
        remain = DURATION_NS - (time.monotonic_ns() - start_m)
        if remain > 0: time.sleep(min(SAMPLE_NS / 1e9, remain / 1e9))
finally:
    stop.set(); thread.join(timeout=3)

end_m = time.monotonic_ns(); end_w = time.time_ns()
(OUT / "clock-samples.jsonl").write_text("".join(json.dumps(x, separators=(",", ":")) + "\n" for x in samples))
(OUT / "timesync-status-samples.jsonl").write_text("".join(json.dumps(x, separators=(",", ":")) + "\n" for x in status_rows))
meta["observer_end_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
meta["observer_elapsed_monotonic_seconds"] = (end_m - start_m) / 1e9
meta["observer_elapsed_wall_seconds"] = (end_w - start_w) / 1e9
meta["state_after"] = state_snapshot("after")
(OUT / "observer-metadata.json").write_text(json.dumps(meta, indent=2) + "\n")

summary = {
    "clock_sample_count": len(samples), "timesync_status_sample_count": len(status_rows),
    "elapsed_monotonic_seconds": (samples[-1]["monotonic_ns"] - samples[0]["monotonic_ns"]) / 1e9,
    "elapsed_monotonic_raw_seconds": (samples[-1]["monotonic_raw_ns"] - samples[0]["monotonic_raw_ns"]) / 1e9,
    "elapsed_boottime_seconds": (samples[-1]["boottime_ns"] - samples[0]["boottime_ns"]) / 1e9,
    "elapsed_wall_seconds": (samples[-1]["wall_unix_ns"] - samples[0]["wall_unix_ns"]) / 1e9,
    "elapsed_raw_syscall_wall_seconds": (samples[-1]["raw_syscall_realtime_ns"] - samples[0]["raw_syscall_realtime_ns"]) / 1e9,
    "elapsed_raw_syscall_monotonic_seconds": (samples[-1]["raw_syscall_monotonic_ns"] - samples[0]["raw_syscall_monotonic_ns"]) / 1e9,
    "max_sample_read_span_us": max(x["read_span_monotonic_ns"] for x in samples) / 1e3,
    "max_python_vs_raw_syscall_realtime_difference_us": max(abs(x["wall_unix_ns"] - x["raw_syscall_realtime_ns"]) for x in samples) / 1e3,
    "max_python_vs_raw_syscall_monotonic_difference_us": max(abs(x["monotonic_ns"] - x["raw_syscall_monotonic_ns"]) for x in samples) / 1e3,
    "timesync_status_failures": sum(1 for x in status_rows if x["command"].get("returncode", 1) != 0),
}
for clock_name, wall_key in (("monotonic", "monotonic_ns"), ("monotonic_raw", "monotonic_raw_ns"), ("boottime", "boottime_ns"), ("raw_syscall_monotonic", "raw_syscall_monotonic_ns")):
    steps=[]
    for i,(a,b) in enumerate(zip(samples,samples[1:]),1):
        residual=(b["wall_unix_ns"]-a["wall_unix_ns"])-(b[wall_key]-a[wall_key])
        if abs(residual)>THRESHOLD_NS:
            steps.append({"sample_index":i,"elapsed_monotonic_seconds":(b["monotonic_ns"]-samples[0]["monotonic_ns"])/1e9,"wall_minus_clock_delta_ms":residual/1e6})
    summary[f"wall_steps_vs_{clock_name}"]=steps
summary["monotonic_minus_raw_drift_ms"] = ((samples[-1]["monotonic_ns"]-samples[0]["monotonic_ns"]) - (samples[-1]["monotonic_raw_ns"]-samples[0]["monotonic_raw_ns"])) / 1e6
summary["boottime_minus_monotonic_ms"] = ((samples[-1]["boottime_ns"]-samples[0]["boottime_ns"]) - (samples[-1]["monotonic_ns"]-samples[0]["monotonic_ns"])) / 1e6
# Retain compact poll changes around packets, including the target's parsed status fields.
changes=[]; last=None
for row in status_rows:
    parsed=row.get("parsed", {})
    key=(parsed.get("Server"),parsed.get("Poll interval"),parsed.get("Offset"),parsed.get("Packet count"),parsed.get("Frequency"))
    if key != last:
        changes.append({"elapsed_monotonic_seconds":(row["before_monotonic_ns"]-start_m)/1e9,"parsed":parsed,"returncode":row["command"].get("returncode"),"stderr":row["command"].get("stderr","")})
        last=key
summary["timesyncd_status_changes"] = changes
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
