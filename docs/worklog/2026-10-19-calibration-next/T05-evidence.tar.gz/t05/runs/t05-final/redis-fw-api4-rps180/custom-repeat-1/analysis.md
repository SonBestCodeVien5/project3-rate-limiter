# Analysis: custom-repeat-1

Pilot observation; not a locked research conclusion.

Policy: `redis` / `fixed-window`; oracle: **inconclusive**.

Requests: 1800; sent: 1800; generator drops: 0.

Observed violations: 0. See `analysis.json` for scope and evidence.

Boundary windows, missing decisions and unknown prior state limit correctness claims. TB uses its own token semantics; FW quota is not applied to TB.
