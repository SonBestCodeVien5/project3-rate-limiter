import datetime as dt, json, pathlib, sys
p=pathlib.Path(sys.argv[1]); s=json.loads((p/'load/summary.json').read_text()); c=json.loads((p/'load/metadata.json').read_text())['config']; a=json.loads((p/'analysis.json').read_text()); rows=[json.loads(x) for x in (p/'load/requests.jsonl').read_text().splitlines()]; flags=[]
if len({r['request_id'] for r in rows})!=len(rows) or s['scheduled']!=len(rows) or s['sent']!=len(rows) or s['generator_dropped']!=0: flags.append('trace/drop reconcile')
if not a['evidence']['summary_counts_match_trace']: flags.append('analyzer reconcile')
start=dt.datetime.fromisoformat(s['started_at']); sent=[r for r in rows if r.get('sent_at')]
def sec(field,r): return (dt.datetime.fromisoformat(r[field])-start).total_seconds()
def check_interval(cl,lo,hi,rps):
    selected=[r for r in rows if r['client_class']==cl and lo <= sec('scheduled_at',r)<hi]
    observed=[r for r in sent if r['client_class']==cl and lo <= sec('sent_at',r)<hi]
    if abs(len(selected)-rps*(hi-lo)) > 1: flags.append(f'schedule samples {cl} {lo}-{hi}: {len(selected)}')
    if abs(len(observed)/(hi-lo)/rps-1)>.05: flags.append(f'sent rate fidelity {cl} {lo}-{hi}: {len(observed)/(hi-lo):.2f}')
    for r in observed:
        wall=(dt.datetime.fromisoformat(r['sent_at'])-dt.datetime.fromisoformat(r['scheduled_at'])).total_seconds()*1000
        lat=(dt.datetime.fromisoformat(r['end_at'])-dt.datetime.fromisoformat(r['sent_at'])).total_seconds()*1000
        if abs(wall-r['schedule_lag_ms'])>5 or abs(lat-r['latency_ms'])>5: flags.append('clock residual'); break
if c['profile']=='normal':
    if len(rows)!=600 or any(r['client_class']!='legitimate' for r in rows): flags.append('normal schedule')
    check_interval('legitimate',0,30,20)
    if s['http_429'] or a['counter_deltas']['backend']['overload']: flags.append('normal outcome')
else:
    for lo,hi,legit,abuse in ((0,2,20,20),(2,4,20,200),(4,30,20,20)):
        check_interval('legitimate',lo,hi,legit); check_interval('abusive',lo,hi,abuse)
    if len(rows)!=1560: flags.append(f'burst total sample count {len(rows)}')
    phase_expect={('base', 'legitimate'):560,('burst','legitimate'):40,('base','abusive'):560,('burst','abusive'):400}
    for (phase,cl),n in phase_expect.items():
        if sum(r['phase']==phase and r['client_class']==cl for r in rows)!=n: flags.append(f'phase label count {cl}/{phase}')
if flags:
    result={'valid':False,'flags':sorted(set(flags)),'sent':s['sent'],'drops':s['generator_dropped']}
    (p/'t04-quality.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result)); sys.exit(1)
result={'valid':True,'profile':c['profile'],'mode':c['mode_label'],'algorithm':c['algorithm_label'],'sent':s['sent'],'drops':s['generator_dropped'],'oracle':a['oracle']['status'],'scheduled_phase_counts': {ph:sum(r['phase']==ph for r in rows) for ph in ('measurement','base','burst')}}
(p/'t04-quality.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
