#!/usr/bin/env python3
"""Bounded causal isolation of Ubuntu systemd-timesyncd; always restore prior active state."""
import csv
import json
import os
import pathlib
import signal
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).resolve().parent / "timesyncd-isolation-20261019-01"
UNIT = "systemd-timesyncd.service"
DURATION_RAW_S = 90.0
STEP_THRESHOLD_NS = 5_000_000


def raw_ns():
    return time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)


def cmd(argv, timeout=4):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        return {"argv": argv, "returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    except Exception as e:
        return {"argv": argv, "error": type(e).__name__ + ": " + str(e)}


def unit_state():
    return cmd(["/usr/bin/systemctl", "show", UNIT, "-p", "LoadState", "-p", "ActiveState",
                "-p", "UnitFileState", "-p", "MainPID", "-p", "FragmentPath", "-p", "DropInPaths"])


def parse_props(result):
    props = {}
    for line in result.get("stdout", "").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            props[k] = v
    return props


def read_sample():
    wall = time.time_ns()
    mono = time.monotonic_ns()
    raw = raw_ns()
    boot = time.clock_gettime_ns(time.CLOCK_BOOTTIME) if hasattr(time, "CLOCK_BOOTTIME") else None
    return wall, mono, raw, boot


def on_signal(signum, frame):
    raise InterruptedError("received signal " + str(signum))


def main():
    if os.geteuid() != 0:
        raise RuntimeError("must run as root in the current Ubuntu distro")
    if OUT.exists():
        raise RuntimeError("output path already exists; refusing to reuse")
    OUT.mkdir(parents=True)
    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT, on_signal)

    record = {"unit": UNIT, "duration_raw_limit_s": DURATION_RAW_S,
              "step_threshold_ns": STEP_THRESHOLD_NS,
              "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    before = unit_state()
    record["before"] = before
    props = parse_props(before)
    was_active = before.get("returncode") == 0 and props.get("LoadState") == "loaded" and props.get("ActiveState") == "active"
    record["was_active"] = was_active
    (OUT / "state.json").write_text(json.dumps(record, indent=2) + "\n")
    if not was_active:
        record["result"] = "aborted_without_change_unit_not_active_or_unavailable"
        (OUT / "state.json").write_text(json.dumps(record, indent=2) + "\n")
        return 20

    stop_attempted = False
    started_raw = None
    steps = []
    n = 0
    failure = None
    try:
        stop_attempted = True
        record["stop"] = cmd(["/usr/bin/systemctl", "stop", UNIT], timeout=8)
        if record["stop"].get("returncode") != 0:
            raise RuntimeError("systemctl stop failed")
        after_stop = unit_state()
        record["after_stop"] = after_stop
        if parse_props(after_stop).get("ActiveState") != "inactive":
            raise RuntimeError("unit did not report inactive after stop")

        with (OUT / "samples.csv").open("w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["elapsed_raw_s", "realtime_ns", "monotonic_ns", "monotonic_raw_ns", "boottime_ns"])
            previous = None
            started_raw = raw_ns()
            deadline = started_raw + int(DURATION_RAW_S * 1e9)
            while raw_ns() < deadline:
                wall, mono, raw, boot = read_sample()
                w.writerow([f"{(raw-started_raw)/1e9:.9f}", wall, mono, raw, boot if boot is not None else ""])
                n += 1
                if previous:
                    prev_wall, prev_mono, prev_raw = previous
                    residual_delta = (wall - prev_wall) - (mono - prev_mono)
                    if abs(residual_delta) > STEP_THRESHOLD_NS:
                        steps.append({"elapsed_raw_s": (raw-started_raw)/1e9,
                                      "residual_step_ns": residual_delta,
                                      "realtime_ns": wall,
                                      "monotonic_raw_ns": raw})
                previous = (wall, mono, raw)
                time.sleep(0.02)
            f.flush()
            os.fsync(f.fileno())
        record["result"] = "sampled"
    except BaseException as e:
        failure = type(e).__name__ + ": " + str(e)
        record["failure"] = failure
        record["result"] = "interrupted_or_failed"
    finally:
        if stop_attempted and was_active:
            record["restore_start"] = cmd(["/usr/bin/systemctl", "start", UNIT], timeout=8)
            record["after_restore"] = unit_state()
            record["restore_verified_active"] = parse_props(record["after_restore"]).get("ActiveState") == "active"
        else:
            record["restore_start"] = {"skipped": "unit was not active before test"}
            record["restore_verified_active"] = not was_active
        record["active_duration_raw_s"] = (raw_ns() - started_raw) / 1e9 if started_raw else 0.0
        record["sample_count"] = n
        record["step_count_over_threshold"] = len(steps)
        record["wall_step_events"] = steps
        record["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        (OUT / "state.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({k: record.get(k) for k in ("result", "failure", "was_active", "active_duration_raw_s",
          "sample_count", "step_count_over_threshold", "wall_step_events", "restore_verified_active", "after_restore")}, sort_keys=True), flush=True)
    return 0 if record.get("restore_verified_active") and record.get("result") == "sampled" else 30


if __name__ == "__main__":
    raise SystemExit(main())
