$ErrorActionPreference = 'Continue'
function Mark($name) { "$name=$([DateTimeOffset]::UtcNow.ToString('o'))" }

Mark 'HOST_UTC_START'
'UBUNTU_UTC'
& wsl.exe --distribution Ubuntu --user root --exec /bin/date -u '+%Y-%m-%dT%H:%M:%S.%N%z'
'WSL_ROOT_CHRONY_TRACKING'
& wsl.exe --system --exec /usr/bin/chronyc -n tracking
Mark 'BEFORE_TIME_WINDOWS'
w32tm /stripchart /computer:time.windows.com /samples:3 /dataonly /packetinfo
Mark 'BEFORE_TIME_CLOUDFLARE'
w32tm /stripchart /computer:time.cloudflare.com /samples:3 /dataonly /packetinfo
Mark 'HOST_UTC_END'
