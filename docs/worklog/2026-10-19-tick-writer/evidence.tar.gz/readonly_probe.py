import os, pathlib, re, subprocess

print('IDENTITY')
for cmd in (['id'], ['uname','-r'], ['getconf','CLK_TCK']):
    try:
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=2)
        print('CMD',cmd,'RC',p.returncode,'OUT',p.stdout.strip(),'ERR',p.stderr.strip())
    except Exception as e: print('CMD',cmd,'ERR',type(e).__name__,str(e))
print('CAPABILITY')
try:
    for line in pathlib.Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('CapEff:','CapBnd:')): print(line)
except Exception as e: print(type(e).__name__,str(e))
print('TARGETED_CONFIG_MATCHES')
paths=[]
for p in [pathlib.Path('/etc/crontab'), pathlib.Path('/etc/adjtime')]:
    if p.is_file(): paths.append(p)
for d in ['/etc/cron.d','/etc/cron.hourly','/etc/cron.daily','/etc/cron.weekly','/etc/cron.monthly','/etc/systemd/system','/lib/systemd/system','/usr/lib/systemd/system']:
    root=pathlib.Path(d)
    if root.is_dir():
        try:
            for p in root.iterdir():
                if p.is_file() and re.search(r'(time|clock|tick|ntp|chrony|timesync)',p.name,re.I): paths.append(p)
        except OSError: pass
pat=re.compile(r'ADJ_TICK|adjtimex|tick.{0,20}9167|9167.{0,20}tick|hwclock|settimeofday|timedatectl|systemd-timesyncd|chronyd|ntpd|ntpdate',re.I)
for p in sorted(set(paths)):
    try:
        for n,line in enumerate(p.read_text(errors='replace').splitlines(),1):
            if pat.search(line): print(f'{p}:{n}:{line[:300]}')
    except (OSError,UnicodeError): pass
print('TRACING_AVAILABILITY')
for cmd in (['sh','-lc','for x in trace-cmd bpftrace perf strace; do command -v "$x" || true; done'],):
    try:
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=3)
        print('TOOLS',p.stdout.strip().replace('\n',','))
    except Exception as e: print('TOOLS_ERR',type(e).__name__,str(e))
for name in ['tracing_on','current_tracer','available_tracers','kprobe_events','set_ftrace_filter','available_filter_functions']:
    p=pathlib.Path('/sys/kernel/tracing')/name
    if not p.exists(): p=pathlib.Path('/sys/kernel/debug/tracing')/name
    print('TRACE_FILE',p, 'exists',p.exists())
    if p.exists() and name in ('tracing_on','current_tracer','available_tracers','kprobe_events'):
        try:
            val=p.read_text(errors='replace').strip()
            print(name,repr(val[:1000]))
        except Exception as e: print(name,'READ_ERR',type(e).__name__,str(e))
    if p.exists() and name=='available_filter_functions':
        try:
            rx=re.compile(r'(^|\s)(do_adjtimex|__do_sys_adjtimex|sys_adjtimex|do_settimeofday64|timekeeping_inject_offset|hv_set_host_time|adjtime|do_clock_adjtime)(\s|$)',re.I)
            found=[]
            with p.open(errors='replace') as f:
                for line in f:
                    if rx.search(line): found.append(line.strip())
            print('TARGET_FUNCTIONS',found[:50])
        except Exception as e: print('FUNCTIONS_ERR',type(e).__name__,str(e))
for f in ['/proc/sys/kernel/perf_event_paranoid','/proc/sys/kernel/kptr_restrict']:
    try: print(f,pathlib.Path(f).read_text().strip())
    except Exception as e: print(f,'READ_ERR',type(e).__name__,str(e))
