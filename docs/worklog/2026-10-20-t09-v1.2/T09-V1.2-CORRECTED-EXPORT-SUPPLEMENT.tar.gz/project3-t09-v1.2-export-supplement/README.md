# T09 v1.2 offline export fingerprint correction

This derived export re-runs the unchanged v1.2 result manifest through report exporter commit `046654e27e08e2292d554fd96a594226ef86bc7e`. The original result manifest and measurement artifacts remain untouched.

## Inputs and provenance

- Original coordinator manifest: `/tmp/project3-t09-v1.2-results-20261020/manifest.json`
- Original manifest SHA-256: `c0f16fb5349ae4653514ff4f7f79d7047ca72453e644bc8f40a1676ac2eebf64`
- Derived manifest copy: `manifest.json`; it adds only `clock_tolerance_ms: 5`, the locked protocol value.
- Derived manifest SHA-256: `b35bf81412d7ec73aba7566e7ed0716765912425d4a9011c29e92279735f8e58`
- Measurement source revision remains `0291a80fb404fea0eafee8c3431acc3631bb423e`.
- Exporter SHA-256: `391c53239e1a4191505f213df30d5924a5c47dec0af15d537c74dd7f2c9106c5`
- Regression test SHA-256: `325aac32e0a982f39ece1337986fb08938bc85fb8f24dc7a7e445139cd7e7f46`

## Command and result

```sh
python3 scripts/report-study.py /tmp/project3-t09-v1.2-export-fix-20261020/manifest.json --output /tmp/project3-t09-v1.2-export-fix-20261020/export
```

The export has 137 usable runs. Of 46 cells, 45 aggregate and one remains incomplete at 2/3 (`scale-redis-fw-1api-250rps`) with no aggregate. The four outage cells aggregate after normalizing only the generated `com.docker.compose.project` label. Comparison of the recorded inspection data confirms that canonical image identities match across repetitions for all four outage cells.

Files: `export/runs.csv`, `export/cells.csv`, and `export/report.md`.
