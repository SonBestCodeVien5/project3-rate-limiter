#!/usr/bin/env python3
import json, os, pathlib, subprocess, sys
manifest_path=pathlib.Path('/tmp/t09-smoke-20261020/manifest-838aca5.json')
repo=pathlib.Path('/tmp/project3-t09-smoke-838aca5')
root=pathlib.Path('/tmp/t09-smoke-20261020')
manifest=json.loads(manifest_path.read_text())
runs={r['planned_run_id']:r for r in manifest['runs']}
kind=sys.argv[1]
run_id=sys.argv[2]
preview='--preview' in sys.argv[3:]
r=runs[run_id]
env=os.environ.copy(); env.update(r['environment'])
argv=list(r['command'])
if kind=='standard':
    assert run_id=='p1-003-normal-none-r1'
    assert argv[:2]==['bash','scripts/research-pilot.sh']
    w=r['config']['workload']; t=r['config']['topology']; p=r['config']['policy']
    assert (w['duration_s'],w['rps'],w['legitimate_rps'])==(30,20,20)
    assert (t['backend_capacity'],t['api_instances'])==(4,2)
    assert p['mode']=='none' and p['algorithm']=='fixed-window'
    out='artifacts/t09-smoke-20261020-838aca5/standard-normal-none-r1'
    argv[argv.index('--output')+1]=out
elif kind in ('outage','invalid-stop'):
    assert argv[:2]==['bash','scripts/redis-outage.sh']
    expected={'p1-043-outage-open-healthy-r1':('open','p1-044-outage-open-outage-r1'),
              'p1-045-outage-closed-healthy-r1':('closed','p1-046-outage-closed-outage-r1')}
    policy,outage_id=expected[run_id]
    w=r['config']['workload']; t=r['config']['topology']; p=r['config']['policy']
    assert (w['duration_s'],w['rps'],w['legitimate_rps'])==(30,100,20)
    assert (t['backend_capacity'],t['api_instances'])==(10,2)
    assert (p['mode'],p['algorithm'],p['fail_policy'])==('redis','fixed-window',policy)
    assert (env['OUTAGE_DURATION'],env['OUTAGE_RPS'],env['OUTAGE_LEGIT_RPS'],env['OUTAGE_PAUSE_AT'],env['OUTAGE_PAUSE_FOR'])==('30','100','20','4','2')
    out=f'artifacts/t09-smoke-20261020-838aca5/outage-{policy}-'+('invalid-stop' if kind=='invalid-stop' else 'matched')
    output_index=argv.index('scripts/redis-outage.sh')+1
    assert argv[output_index]=='artifacts/protocol-v1.1/'+f'outage-{policy}-r1'
    argv[output_index]=out
    argv[argv.index('<ABSOLUTE_PROTOCOL_V1_1_MANIFEST>')]=str(manifest_path)
    if kind=='invalid-stop': argv[argv.index('--healthy-run-id')+1]='intentionally-invalid-healthy-id'
else: raise SystemExit('kind must be standard, outage, or invalid-stop')
run_root=repo/out
assert preview or not run_root.exists(), f'output already exists: {run_root}'
assert argv[0]=='bash' and argv[1] in ('scripts/research-pilot.sh','scripts/redis-outage.sh')
if kind=='outage':
    assert argv[argv.index('--healthy-run-id')+1]==run_id
    assert argv[argv.index('--outage-run-id')+1]==('p1-044-outage-open-outage-r1' if 'open' in run_id else 'p1-046-outage-closed-outage-r1')
receipt=root/(f'{kind}-{run_id}'+('.preview.json' if preview else '.invocation.json'))
receipt.write_text(json.dumps({'source_revision':manifest['source_revision'],'manifest_sha256':__import__('hashlib').sha256(manifest_path.read_bytes()).hexdigest(),'planned_run_id':run_id,'kind':kind,'environment':{k:v for k,v in env.items() if k in r['environment']},'argv':argv,'cwd':str(repo)},indent=2)+'\n')
if preview:
    print(json.dumps({'kind':kind,'planned_run_id':run_id,'argv':argv,'manifest_environment':{k:env[k] for k in r['environment']},'assertions':'passed'}))
    raise SystemExit(0)
log=root/f'{kind}-{run_id}.launcher.log'
with log.open('wb') as f:
    result=subprocess.run(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
print(json.dumps({'kind':kind,'planned_run_id':run_id,'returncode':result.returncode,'receipt':str(receipt),'log':str(log),'artifact_root':str(run_root)}))
sys.exit(result.returncode)
