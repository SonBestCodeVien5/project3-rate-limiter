# Analysis: t07-20261020T065103-32672-closed-outage

Pilot observation; not a locked research conclusion.

Policy: `redis` / `fixed-window`; oracle: **inconclusive**.

Requests: 3000; sent: 3000; generator drops: 0.

Observed violations: 0. See `analysis.json` for scope and evidence.

## Redis outage

Availability uses legitimate successes divided by legitimate requests sent in each send-time phase.

- before: 81/81 legitimate successful/sent; availability 1.0.
- pausing: 8/9 legitimate successful/sent; availability 0.8888888888888888.
- outage: 0/40 legitimate successful/sent; availability 0.0.
- unpausing: 2/8 legitimate successful/sent; availability 0.25.
- after: 461/462 legitimate successful/sent; availability 0.9978354978354979.

Stable recovery: 4000 ms (observed).

Boundary windows, missing decisions and unknown prior state limit correctness claims. TB uses its own token semantics; FW quota is not applied to TB.
