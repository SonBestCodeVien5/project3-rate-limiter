import json,time,urllib.request,pathlib,shutil
out=pathlib.Path('artifacts/postfix-20261013/console');out.mkdir()
c=dict(mode='none',algorithm='fixed-window',profile='mixed',fail_policy='closed',instances=2,rps=120,legitimate_rps=20,duration_seconds=6,limit=20,window_ms=1000,capacity=20,refill_rate=20,backend_capacity=4,backend_service_ms=50,burst_start_seconds=1,burst_duration_seconds=1,burst_rps=200,concurrent_at_seconds=2,concurrent_count=100)
ids={}
for mode in ('none','local','redis'):
 c['mode']=mode;data=dict(case='custom',repetitions=1,mixed_rps=0,custom=c.copy());req=urllib.request.Request('http://127.0.0.1:8090/api/runs',data=json.dumps(data).encode(),headers={'Content-Type':'application/json'},method='POST')
 with urllib.request.urlopen(req,timeout=10) as r:created=json.load(r)
 id=created['id'];ids[mode]=id
 for _ in range(150):
  with urllib.request.urlopen('http://127.0.0.1:8090/api/runs/'+id,timeout=10) as r:result=json.load(r)
  if result['run']['state']!='running':break
  time.sleep(2)
 (out/(mode+'-http.json')).write_text(json.dumps(result,indent=2)+'\n')
 assert result['run']['state']=='completed',result
 assert set(result['summaries'])==set(result['analyses'])=={'1'}
 shutil.copytree(pathlib.Path('artifacts/console')/id,out/(mode+'-'+id))
 print(mode,id,flush=True)
(out/'ids.json').write_text(json.dumps(ids,indent=2)+'\n')
