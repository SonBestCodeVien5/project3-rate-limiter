#!/usr/bin/env python3
"""One bounded isolated tracefs instance for ADJ_TICK submissions only."""
import json, os, pathlib, re, signal, subprocess, sys, time

OUT = pathlib.Path(__file__).resolve().parent
TRACE = pathlib.Path('/sys/kernel/tracing')
INST = TRACE / 'instances' / 'tickwriter_20261019_1107'
GROUP = 'tickwriter_20261019_1107'
EVENT = 'adj_tick'
KPROBES = TRACE / 'kprobe_events'
PROBE = f'p:{GROUP}/{EVENT} do_adjtimex modes=(struct __kernel_timex)$arg1->modes:x32 tick=(struct __kernel_timex)$arg1->tick:s64'
MAX_RAW_NS = 45_000_000_000
completed = False

class StopRequested(Exception): pass

def on_signal(signum, frame): raise StopRequested(f'signal {signum}')
signal.signal(signal.SIGTERM, on_signal)
signal.signal(signal.SIGINT, on_signal)

def raw_ns(): return time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
def read(path): return path.read_text(errors='replace')
def write(path, value): path.write_text(str(value))
def run(args, timeout=4):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        return {'argv':args,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    except Exception as e: return {'argv':args,'error':type(e).__name__+': '+str(e)}
def tracewrite(path, value):
    with path.open('w') as f: f.write(value)
def query_tick():
    ctl=pathlib.Path('/home/khanhson2005/projects/project3-rate-limiter/artifacts/tick-trial-20261019-0417-dd307a6/tickctl')
    if not ctl.exists(): return {'error':'existing read-only tickctl unavailable'}
    return run([str(ctl),'query'],2)
def event_pids(trace):
    found={}
    for line in trace.splitlines():
        if f'{GROUP}:{EVENT}:' not in line: continue
        m=re.search(r'^\s*(.*?)-(\d+)\s+\[',line)
        if m: found[int(m.group(2))]=m.group(1)
    out=[]
    for pid,comm in sorted(found.items()):
        base=pathlib.Path('/proc')/str(pid)
        item={'pid':pid,'trace_comm':comm}
        try: item['comm']=(base/'comm').read_text().strip()
        except OSError: item['comm']='exited_before_snapshot'
        try:
            for ln in (base/'status').read_text().splitlines():
                if ln.startswith('PPid:'): item['ppid']=int(ln.split()[1]); break
        except OSError: pass
        try: item['exe']=os.path.basename(os.readlink(base/'exe'))
        except OSError: item['exe']='unavailable_or_exited'
        try: item['cgroup']=[x for x in (base/'cgroup').read_text().splitlines() if x][:8]
        except OSError: pass
        out.append(item)
    return out

result={'probe':PROBE,'group':GROUP,'event':EVENT,'max_duration_raw_seconds':45,'status':'starting','revision':'02dca6c8ca317e40782d3f81ced69f7cd98fc081'}
if os.geteuid()!=0:
    result.update(status='aborted',reason='native probe process is not root'); (OUT/'trace-result.json').write_text(json.dumps(result,indent=2)+'\n'); raise SystemExit(20)
if not TRACE.is_dir() or not (TRACE/'instances').is_dir() or not KPROBES.exists():
    result.update(status='aborted',reason='tracefs instances or kprobe_events unavailable'); (OUT/'trace-result.json').write_text(json.dumps(result,indent=2)+'\n'); raise SystemExit(21)
if INST.exists():
    result.update(status='aborted',reason='unique instance already exists; refusing to reuse'); (OUT/'trace-result.json').write_text(json.dumps(result,indent=2)+'\n'); raise SystemExit(22)
try:
    result['global_before']={'tracing_on':read(TRACE/'tracing_on').strip(),'current_tracer':read(TRACE/'current_tracer').strip()}
except Exception as e: result['global_before_error']=type(e).__name__+': '+str(e)
result['tick_before']=query_tick()
created_instance=False; registered=False; enabled=False; started_raw=None; trace_text=''; failure=None
try:
    INST.mkdir()
    created_instance=True
    tracewrite(INST/'buffer_size_kb','64')
    registered=True
    tracewrite(KPROBES,PROBE+'\n')
    event_enable=INST/'events'/GROUP/EVENT/'enable'
    event_filter=INST/'events'/GROUP/EVENT/'filter'
    if not event_enable.exists() or not event_filter.exists(): raise RuntimeError('instance event controls unavailable after probe registration')
    fmt=read(INST/'events'/GROUP/EVENT/'format')
    (OUT/'event-format.txt').write_text(fmt)
    for field in ('modes','tick'):
        if field not in fmt: raise RuntimeError('generated format missing expected field '+field)
    filter_expr='modes & 16384'
    tracewrite(event_filter,filter_expr)
    filter_actual=read(event_filter).strip()
    if filter_actual!=filter_expr: raise RuntimeError('filter readback mismatch: '+repr(filter_actual))
    result['format_validated']=True
    result['filter']=filter_actual
    result['buffer_size_kb']=read(INST/'buffer_size_kb').strip()
    result['instance_tracing_on_before']=read(INST/'tracing_on').strip()
    # Event-specific enable and instance-local tracing only.
    tracewrite(event_enable,'1')
    enabled=True
    tracewrite(INST/'tracing_on','1')
    started_raw=raw_ns()
    result['started_raw_ns']=started_raw
    result['status']='capturing'
    (OUT/'trace-start.json').write_text(json.dumps(result,indent=2)+'\n')
    deadline=started_raw+MAX_RAW_NS
    while raw_ns()<deadline: time.sleep(0.05)
    result['duration_limit_reached']=True
except BaseException as e:
    failure=type(e).__name__+': '+str(e)
finally:
    if INST.exists():
        try: tracewrite(INST/'tracing_on','0')
        except Exception as e: result['disable_instance_error']=type(e).__name__+': '+str(e)
        try:
            trace_text=read(INST/'trace')
            (OUT/'trace.txt').write_text(trace_text)
        except Exception as e: result['trace_read_error']=type(e).__name__+': '+str(e)
        try:
            if (INST/'events'/GROUP/EVENT/'enable').exists(): tracewrite(INST/'events'/GROUP/EVENT/'enable','0')
            enabled=False
        except Exception as e: result['event_disable_error']=type(e).__name__+': '+str(e)
    if registered:
        try:
            tracewrite(KPROBES,f'-:{GROUP}/{EVENT}\n')
            registered=False
            result['probe_unregister_verified']=f'{GROUP}/{EVENT}' not in read(KPROBES)
        except Exception as e: result['probe_unregister_error']=type(e).__name__+': '+str(e)
    if created_instance and INST.exists():
        try: INST.rmdir(); created_instance=False; result['instance_removed']=True
        except Exception as e: result['instance_remove_error']=type(e).__name__+': '+str(e)
    result['status']='complete' if failure is None else 'failed'
    result['failure']=failure
    result['duration_raw_seconds']=((raw_ns()-started_raw)/1e9) if started_raw else 0
    result['event_count']=sum(1 for line in trace_text.splitlines() if f'{GROUP}:{EVENT}:' in line)
    result['event_processes']=event_pids(trace_text)
    result['tick_after_cleanup']=query_tick()
    try: result['global_after']={'tracing_on':read(TRACE/'tracing_on').strip(),'current_tracer':read(TRACE/'current_tracer').strip()}
    except Exception as e: result['global_after_error']=type(e).__name__+': '+str(e)
    result['instance_removed']=result.get('instance_removed',not INST.exists())
    result['probe_registered_after_cleanup']=f'{GROUP}/{EVENT}' in read(KPROBES) if KPROBES.exists() else None
    result['event_enabled_after_cleanup']=enabled
    result['completed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    (OUT/'trace-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('TRACE_COMPLETE '+json.dumps(result,sort_keys=True),flush=True)
if failure is not None: raise SystemExit(30)
