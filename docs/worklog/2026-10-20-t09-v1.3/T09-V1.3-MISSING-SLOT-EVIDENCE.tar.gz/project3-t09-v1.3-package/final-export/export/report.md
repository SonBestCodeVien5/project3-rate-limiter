# Study artifact report

Measured artifacts only. No winner or final research conclusion is inferred.

Business problem → pain point → business impact → technical requirement → solution → experiment → evaluation → future development must be supplied in the research report.

Tooling validity, correctness oracle and research claims are separate. FW inconclusive/partial windows do not invalidate a run by themselves. Errors/overload may be intended outcomes; flags require interpretation against the locked protocol.

Cell statistics are median/min/max of separate run metrics. A median of run p95/p99 is not a pooled percentile. No aggregation is exported for incomplete, incompatible or invalid-evidence cells.

Client clock check compares wall-clock sent−scheduled with monotonic schedule lag; it cannot diagnose server clock steps. Tolerance (ms): 5

| Cell | Runs / expected | Aggregation |
| --- | --- | --- |
| normal-none | 3 / 3 | complete_same_config |
| normal-local-fw | 3 / 3 | complete_same_config |
| normal-redis-fw | 3 / 3 | complete_same_config |
| normal-local-tb | 3 / 3 | complete_same_config |
| normal-redis-tb | 3 / 3 | complete_same_config |
| burst-none | 3 / 3 | complete_same_config |
| burst-local-fw | 3 / 3 | complete_same_config |
| burst-redis-fw | 3 / 3 | complete_same_config |
| burst-local-tb | 3 / 3 | complete_same_config |
| burst-redis-tb | 3 / 3 | complete_same_config |
| mixed-none | 3 / 3 | complete_same_config |
| mixed-local-fw | 3 / 3 | complete_same_config |
| mixed-redis-fw | 3 / 3 | complete_same_config |
| mixed-local-tb | 3 / 3 | complete_same_config |
| mixed-redis-tb | 3 / 3 | complete_same_config |
| scale-none-fw-1api-50rps | 3 / 3 | complete_same_config |
| scale-none-fw-1api-180rps | 3 / 3 | complete_same_config |
| scale-none-fw-1api-250rps | 3 / 3 | complete_same_config |
| scale-none-fw-2api-50rps | 3 / 3 | complete_same_config |
| scale-none-fw-2api-180rps | 3 / 3 | complete_same_config |
| scale-none-fw-2api-250rps | 3 / 3 | complete_same_config |
| scale-none-fw-4api-50rps | 3 / 3 | complete_same_config |
| scale-none-fw-4api-180rps | 3 / 3 | complete_same_config |
| scale-none-fw-4api-250rps | 3 / 3 | complete_same_config |
| scale-local-fw-1api-50rps | 3 / 3 | complete_same_config |
| scale-local-fw-1api-180rps | 3 / 3 | complete_same_config |
| scale-local-fw-1api-250rps | 3 / 3 | complete_same_config |
| scale-local-fw-2api-50rps | 3 / 3 | complete_same_config |
| scale-local-fw-2api-180rps | 3 / 3 | complete_same_config |
| scale-local-fw-2api-250rps | 3 / 3 | complete_same_config |
| scale-local-fw-4api-50rps | 3 / 3 | complete_same_config |
| scale-local-fw-4api-180rps | 3 / 3 | complete_same_config |
| scale-local-fw-4api-250rps | 3 / 3 | complete_same_config |
| scale-redis-fw-1api-50rps | 3 / 3 | complete_same_config |
| scale-redis-fw-1api-180rps | 3 / 3 | complete_same_config |
| scale-redis-fw-1api-250rps | 3 / 3 | complete_same_config |
| scale-redis-fw-2api-50rps | 3 / 3 | complete_same_config |
| scale-redis-fw-2api-180rps | 3 / 3 | complete_same_config |
| scale-redis-fw-2api-250rps | 3 / 3 | complete_same_config |
| scale-redis-fw-4api-50rps | 3 / 3 | complete_same_config |
| scale-redis-fw-4api-180rps | 3 / 3 | complete_same_config |
| scale-redis-fw-4api-250rps | 3 / 3 | complete_same_config |
| outage-open-healthy | 3 / 3 | complete_same_config |
| outage-open-outage | 3 / 3 | complete_same_config |
| outage-closed-healthy | 3 / 3 | complete_same_config |
| outage-closed-outage | 3 / 3 | complete_same_config |

| Cell | Metric | Median of runs | Run min | Run max |
| --- | --- | --- | --- | --- |
| normal-none | legitimate_goodput_per_second | 19.997501576145083 | 19.997419499658733 | 19.997578583198464 |
| normal-none | legitimate_p95_ms | 54.115577 | 54.091594 | 54.118891 |
| normal-none | legitimate_p99_ms | 54.533141 | 54.48951 | 54.564319 |
| normal-none | http_429 | 0 | 0 | 0 |
| normal-none | http_5xx | 0 | 0 | 0 |
| normal-none | backend_arrivals | 600 | 600 | 600 |
| normal-none | backend_overload | 0 | 0 | 0 |
| normal-local-fw | legitimate_goodput_per_second | 19.99760815608008 | 19.997329917847864 | 19.99787678342636 |
| normal-local-fw | legitimate_p95_ms | 54.056857 | 53.993084 | 54.109056 |
| normal-local-fw | legitimate_p99_ms | 54.476546 | 54.281698 | 54.650485 |
| normal-local-fw | http_429 | 0 | 0 | 0 |
| normal-local-fw | http_5xx | 0 | 0 | 0 |
| normal-local-fw | backend_arrivals | 600 | 600 | 600 |
| normal-local-fw | backend_overload | 0 | 0 | 0 |
| normal-redis-fw | legitimate_goodput_per_second | 19.99700660608742 | 19.99696222414087 | 19.99724948565182 |
| normal-redis-fw | legitimate_p95_ms | 54.596894 | 54.566405 | 54.617631 |
| normal-redis-fw | legitimate_p99_ms | 55.145653 | 55.073835 | 55.235387 |
| normal-redis-fw | http_429 | 0 | 0 | 0 |
| normal-redis-fw | http_5xx | 0 | 0 | 0 |
| normal-redis-fw | backend_arrivals | 600 | 600 | 600 |
| normal-redis-fw | backend_overload | 0 | 0 | 0 |
| normal-local-tb | legitimate_goodput_per_second | 19.99753741858603 | 19.99745483793372 | 19.997808974056035 |
| normal-local-tb | legitimate_p95_ms | 54.102449 | 53.86006 | 54.109455 |
| normal-local-tb | legitimate_p99_ms | 54.593827 | 54.481601 | 55.13953 |
| normal-local-tb | http_429 | 0 | 0 | 0 |
| normal-local-tb | http_5xx | 0 | 0 | 0 |
| normal-local-tb | backend_arrivals | 600 | 600 | 600 |
| normal-local-tb | backend_overload | 0 | 0 | 0 |
| normal-redis-tb | legitimate_goodput_per_second | 19.99713239321739 | 19.996904193275153 | 19.997393932290365 |
| normal-redis-tb | legitimate_p95_ms | 54.575182 | 54.546914 | 54.591001 |
| normal-redis-tb | legitimate_p99_ms | 55.164052 | 55.097577 | 55.189983 |
| normal-redis-tb | http_429 | 0 | 0 | 0 |
| normal-redis-tb | http_5xx | 0 | 0 | 0 |
| normal-redis-tb | backend_arrivals | 600 | 600 | 600 |
| normal-redis-tb | backend_overload | 0 | 0 | 0 |
| burst-none | legitimate_goodput_per_second | 18.931010839061575 | 18.897747517000656 | 18.99767805439423 |
| burst-none | legitimate_p95_ms | 53.767424 | 53.580416 | 53.768787 |
| burst-none | legitimate_p99_ms | 54.107913 | 54.072963 | 54.209229 |
| burst-none | http_429 | 0 | 0 | 0 |
| burst-none | http_5xx | 294 | 294 | 294 |
| burst-none | backend_arrivals | 1560 | 1560 | 1560 |
| burst-none | backend_overload | 294 | 294 | 294 |
| burst-local-fw | legitimate_goodput_per_second | 19.663646016675624 | 19.63042517221794 | 19.731043203107163 |
| burst-local-fw | legitimate_p95_ms | 53.680055 | 53.648873 | 53.73 |
| burst-local-fw | legitimate_p99_ms | 54.1863 | 54.185805 | 54.432616 |
| burst-local-fw | http_429 | 300 | 300 | 300 |
| burst-local-fw | http_5xx | 74 | 73 | 77 |
| burst-local-fw | backend_arrivals | 1260 | 1260 | 1260 |
| burst-local-fw | backend_overload | 74 | 73 | 77 |
| burst-redis-fw | legitimate_goodput_per_second | 19.830573675666614 | 19.796926699363187 | 19.930477159764745 |
| burst-redis-fw | legitimate_p95_ms | 54.334352 | 54.329183 | 54.505027 |
| burst-redis-fw | legitimate_p99_ms | 54.895112 | 54.782516 | 55.063271 |
| burst-redis-fw | http_429 | 360 | 360 | 360 |
| burst-redis-fw | http_5xx | 35 | 34 | 39 |
| burst-redis-fw | backend_arrivals | 1200 | 1200 | 1200 |
| burst-redis-fw | backend_overload | 35 | 34 | 39 |
| burst-local-tb | legitimate_goodput_per_second | 19.797587363716325 | 19.63070724397841 | 19.83095059107625 |
| burst-local-tb | legitimate_p95_ms | 53.701808 | 53.622227 | 53.832646 |
| burst-local-tb | legitimate_p99_ms | 54.27495 | 54.246761 | 54.460022 |
| burst-local-tb | http_429 | 283 | 283 | 283 |
| burst-local-tb | http_5xx | 41 | 39 | 47 |
| burst-local-tb | backend_arrivals | 1277 | 1277 | 1277 |
| burst-local-tb | backend_overload | 41 | 39 | 47 |
| burst-redis-tb | legitimate_goodput_per_second | 19.93017197623751 | 19.929986966284442 | 19.930833602867974 |
| burst-redis-tb | legitimate_p95_ms | 54.312582 | 54.283828 | 54.393623 |
| burst-redis-tb | legitimate_p99_ms | 54.895323 | 54.853843 | 55.026856 |
| burst-redis-tb | http_429 | 342 | 342 | 342 |
| burst-redis-tb | http_5xx | 16 | 16 | 17 |
| burst-redis-tb | backend_arrivals | 1218 | 1218 | 1218 |
| burst-redis-tb | backend_overload | 16 | 16 | 17 |
| mixed-none | legitimate_goodput_per_second | 7.821783813545697 | 7.760488276541013 | 8.021722642780274 |
| mixed-none | legitimate_p95_ms | 53.41402 | 53.26118 | 53.414455 |
| mixed-none | legitimate_p99_ms | 53.984645 | 53.625337 | 54.24859 |
| mixed-none | http_429 | 0 | 0 | 0 |
| mixed-none | http_5xx | 1575 | 1572 | 1580 |
| mixed-none | backend_arrivals | 3600 | 3600 | 3600 |
| mixed-none | backend_overload | 1575 | 1572 | 1580 |
| mixed-local-fw | legitimate_goodput_per_second | 15.264626595624863 | 14.79791715221992 | 15.410952096986401 |
| mixed-local-fw | legitimate_p95_ms | 53.511405 | 53.445635 | 53.528013 |
| mixed-local-fw | legitimate_p99_ms | 54.16162 | 54.104785 | 54.178866 |
| mixed-local-fw | http_429 | 1794 | 1784 | 1800 |
| mixed-local-fw | http_5xx | 593 | 591 | 595 |
| mixed-local-fw | backend_arrivals | 1806 | 1800 | 1816 |
| mixed-local-fw | backend_overload | 593 | 591 | 595 |
| mixed-redis-fw | legitimate_goodput_per_second | 17.59736514593012 | 17.464375412216523 | 17.863829571363645 |
| mixed-redis-fw | legitimate_p95_ms | 54.043189 | 54.000114 | 54.136107 |
| mixed-redis-fw | legitimate_p99_ms | 54.734393 | 54.588988 | 55.215069 |
| mixed-redis-fw | http_429 | 2380 | 2380 | 2386 |
| mixed-redis-fw | http_5xx | 300 | 298 | 306 |
| mixed-redis-fw | backend_arrivals | 1220 | 1214 | 1220 |
| mixed-redis-fw | backend_overload | 300 | 298 | 306 |
| mixed-local-tb | legitimate_goodput_per_second | 18.545671293942373 | 15.644366483727227 | 19.312103661375847 |
| mixed-local-tb | legitimate_p95_ms | 53.359596 | 53.326414 | 53.502245 |
| mixed-local-tb | legitimate_p99_ms | 53.721756 | 53.595228 | 54.146092 |
| mixed-local-tb | http_429 | 1762 | 1762 | 1762 |
| mixed-local-tb | http_5xx | 174 | 86 | 194 |
| mixed-local-tb | backend_arrivals | 1838 | 1838 | 1838 |
| mixed-local-tb | backend_overload | 174 | 86 | 194 |
| mixed-redis-tb | legitimate_goodput_per_second | 19.923597085184504 | 19.890877718593917 | 19.923763664071533 |
| mixed-redis-tb | legitimate_p95_ms | 54.005597 | 53.892096 | 54.032697 |
| mixed-redis-tb | legitimate_p99_ms | 54.512002 | 54.416217 | 54.532591 |
| mixed-redis-tb | http_429 | 2381 | 2381 | 2381 |
| mixed-redis-tb | http_5xx | 12 | 12 | 12 |
| mixed-redis-tb | backend_arrivals | 1219 | 1219 | 1219 |
| mixed-redis-tb | backend_overload | 12 | 12 | 12 |
| scale-none-fw-1api-50rps | legitimate_goodput_per_second | 49.945039482981805 | 49.94390567381652 | 49.94567820134428 |
| scale-none-fw-1api-50rps | legitimate_p95_ms | 54.226368 | 54.156101 | 54.269459 |
| scale-none-fw-1api-50rps | legitimate_p99_ms | 54.491413 | 54.469068 | 54.643121 |
| scale-none-fw-1api-50rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-1api-50rps | http_5xx | 0 | 0 | 0 |
| scale-none-fw-1api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-none-fw-1api-50rps | backend_overload | 0 | 0 | 0 |
| scale-none-fw-1api-180rps | legitimate_goodput_per_second | 179.7111559977411 | 179.70915799184996 | 179.7132569254455 |
| scale-none-fw-1api-180rps | legitimate_p95_ms | 53.507397 | 53.503245 | 53.550003 |
| scale-none-fw-1api-180rps | legitimate_p99_ms | 53.89194 | 53.881536 | 53.968445 |
| scale-none-fw-1api-180rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-1api-180rps | http_5xx | 0 | 0 | 0 |
| scale-none-fw-1api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-none-fw-1api-180rps | backend_overload | 0 | 0 | 0 |
| scale-none-fw-1api-250rps | legitimate_goodput_per_second | 190.91378852658218 | 190.79086590364838 | 191.2186547238764 |
| scale-none-fw-1api-250rps | legitimate_p95_ms | 53.498306 | 53.434046 | 53.595845 |
| scale-none-fw-1api-250rps | legitimate_p99_ms | 53.958916 | 53.869479 | 54.003454 |
| scale-none-fw-1api-250rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-1api-250rps | http_5xx | 1764 | 1754 | 1767 |
| scale-none-fw-1api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-none-fw-1api-250rps | backend_overload | 1764 | 1754 | 1767 |
| scale-none-fw-2api-50rps | legitimate_goodput_per_second | 49.94352236327637 | 49.94309626282592 | 49.94402647094455 |
| scale-none-fw-2api-50rps | legitimate_p95_ms | 54.191772 | 53.992619 | 54.194283 |
| scale-none-fw-2api-50rps | legitimate_p99_ms | 54.645235 | 54.425995 | 54.702566 |
| scale-none-fw-2api-50rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-2api-50rps | http_5xx | 0 | 0 | 0 |
| scale-none-fw-2api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-none-fw-2api-50rps | backend_overload | 0 | 0 | 0 |
| scale-none-fw-2api-180rps | legitimate_goodput_per_second | 179.70985403178395 | 179.67954448037517 | 179.7155840396556 |
| scale-none-fw-2api-180rps | legitimate_p95_ms | 53.473379 | 53.407473 | 53.739919 |
| scale-none-fw-2api-180rps | legitimate_p99_ms | 53.87631 | 53.800821 | 54.237798 |
| scale-none-fw-2api-180rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-2api-180rps | http_5xx | 0 | 0 | 1 |
| scale-none-fw-2api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-none-fw-2api-180rps | backend_overload | 0 | 0 | 1 |
| scale-none-fw-2api-250rps | legitimate_goodput_per_second | 191.1432348873457 | 191.017230462449 | 191.28965398635367 |
| scale-none-fw-2api-250rps | legitimate_p95_ms | 53.370197 | 53.315781 | 53.658122 |
| scale-none-fw-2api-250rps | legitimate_p99_ms | 53.834662 | 53.670437 | 54.070818 |
| scale-none-fw-2api-250rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-2api-250rps | http_5xx | 1756 | 1752 | 1760 |
| scale-none-fw-2api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-none-fw-2api-250rps | backend_overload | 1756 | 1752 | 1760 |
| scale-none-fw-4api-50rps | legitimate_goodput_per_second | 49.944276105671015 | 49.944045431761545 | 49.94447193421661 |
| scale-none-fw-4api-50rps | legitimate_p95_ms | 54.098409 | 54.052752 | 54.130936 |
| scale-none-fw-4api-50rps | legitimate_p99_ms | 54.592335 | 54.41016 | 54.718175 |
| scale-none-fw-4api-50rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-4api-50rps | http_5xx | 0 | 0 | 0 |
| scale-none-fw-4api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-none-fw-4api-50rps | backend_overload | 0 | 0 | 0 |
| scale-none-fw-4api-180rps | legitimate_goodput_per_second | 179.71245345506318 | 179.70755395437615 | 179.7207993948874 |
| scale-none-fw-4api-180rps | legitimate_p95_ms | 53.527905 | 53.426481 | 53.642582 |
| scale-none-fw-4api-180rps | legitimate_p99_ms | 53.91856 | 53.890949 | 54.177759 |
| scale-none-fw-4api-180rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-4api-180rps | http_5xx | 0 | 0 | 0 |
| scale-none-fw-4api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-none-fw-4api-180rps | backend_overload | 0 | 0 | 0 |
| scale-none-fw-4api-250rps | legitimate_goodput_per_second | 190.98309570150445 | 190.946756965085 | 191.31145602057157 |
| scale-none-fw-4api-250rps | legitimate_p95_ms | 53.564999 | 53.395613 | 53.578735 |
| scale-none-fw-4api-250rps | legitimate_p99_ms | 54.00717 | 53.814412 | 54.101049 |
| scale-none-fw-4api-250rps | http_429 | 0 | 0 | 0 |
| scale-none-fw-4api-250rps | http_5xx | 1761 | 1752 | 1762 |
| scale-none-fw-4api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-none-fw-4api-250rps | backend_overload | 1761 | 1752 | 1762 |
| scale-local-fw-1api-50rps | legitimate_goodput_per_second | 49.943765870091916 | 49.94284973613656 | 49.94395684552454 |
| scale-local-fw-1api-50rps | legitimate_p95_ms | 54.057231 | 54.02382 | 54.206264 |
| scale-local-fw-1api-50rps | legitimate_p99_ms | 54.454703 | 54.432751 | 54.48573 |
| scale-local-fw-1api-50rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-1api-50rps | http_5xx | 0 | 0 | 0 |
| scale-local-fw-1api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-local-fw-1api-50rps | backend_overload | 0 | 0 | 0 |
| scale-local-fw-1api-180rps | legitimate_goodput_per_second | 179.70977625317138 | 179.70759453220967 | 179.71100152084492 |
| scale-local-fw-1api-180rps | legitimate_p95_ms | 53.510143 | 53.449149 | 53.699061 |
| scale-local-fw-1api-180rps | legitimate_p99_ms | 53.84253 | 53.820183 | 54.154899 |
| scale-local-fw-1api-180rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-1api-180rps | http_5xx | 0 | 0 | 0 |
| scale-local-fw-1api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-local-fw-1api-180rps | backend_overload | 0 | 0 | 0 |
| scale-local-fw-1api-250rps | legitimate_goodput_per_second | 191.18663940702294 | 191.15044176307043 | 191.41614985651753 |
| scale-local-fw-1api-250rps | legitimate_p95_ms | 53.324615 | 53.293861 | 53.422703 |
| scale-local-fw-1api-250rps | legitimate_p99_ms | 53.764062 | 53.620288 | 53.776335 |
| scale-local-fw-1api-250rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-1api-250rps | http_5xx | 1755 | 1748 | 1756 |
| scale-local-fw-1api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-local-fw-1api-250rps | backend_overload | 1755 | 1748 | 1756 |
| scale-local-fw-2api-50rps | legitimate_goodput_per_second | 49.94463334562677 | 49.944483861017716 | 49.945297363117746 |
| scale-local-fw-2api-50rps | legitimate_p95_ms | 54.146425 | 54.094677 | 54.165297 |
| scale-local-fw-2api-50rps | legitimate_p99_ms | 54.55269 | 54.489348 | 54.565423 |
| scale-local-fw-2api-50rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-2api-50rps | http_5xx | 0 | 0 | 0 |
| scale-local-fw-2api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-local-fw-2api-50rps | backend_overload | 0 | 0 | 0 |
| scale-local-fw-2api-180rps | legitimate_goodput_per_second | 179.70921834834982 | 179.70665906380682 | 179.71356750808752 |
| scale-local-fw-2api-180rps | legitimate_p95_ms | 53.46251 | 53.415774 | 53.46628 |
| scale-local-fw-2api-180rps | legitimate_p99_ms | 53.817739 | 53.751042 | 53.834647 |
| scale-local-fw-2api-180rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-2api-180rps | http_5xx | 0 | 0 | 0 |
| scale-local-fw-2api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-local-fw-2api-180rps | backend_overload | 0 | 0 | 0 |
| scale-local-fw-2api-250rps | legitimate_goodput_per_second | 191.1384628162032 | 190.87622446618724 | 191.18806633287647 |
| scale-local-fw-2api-250rps | legitimate_p95_ms | 53.514492 | 53.411649 | 53.614628 |
| scale-local-fw-2api-250rps | legitimate_p99_ms | 53.887056 | 53.858066 | 53.995415 |
| scale-local-fw-2api-250rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-2api-250rps | http_5xx | 1757 | 1755 | 1765 |
| scale-local-fw-2api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-local-fw-2api-250rps | backend_overload | 1757 | 1755 | 1765 |
| scale-local-fw-4api-50rps | legitimate_goodput_per_second | 49.943872104288495 | 49.94353127976716 | 49.944362592722555 |
| scale-local-fw-4api-50rps | legitimate_p95_ms | 54.035875 | 54.003984 | 54.28478 |
| scale-local-fw-4api-50rps | legitimate_p99_ms | 54.389536 | 54.330455 | 54.673629 |
| scale-local-fw-4api-50rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-4api-50rps | http_5xx | 0 | 0 | 0 |
| scale-local-fw-4api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-local-fw-4api-50rps | backend_overload | 0 | 0 | 0 |
| scale-local-fw-4api-180rps | legitimate_goodput_per_second | 179.7036522465415 | 179.61433932509533 | 179.71669392077985 |
| scale-local-fw-4api-180rps | legitimate_p95_ms | 53.61041 | 53.566741 | 53.70777 |
| scale-local-fw-4api-180rps | legitimate_p99_ms | 54.081686 | 54.061864 | 54.551617 |
| scale-local-fw-4api-180rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-4api-180rps | http_5xx | 0 | 0 | 3 |
| scale-local-fw-4api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-local-fw-4api-180rps | backend_overload | 0 | 0 | 3 |
| scale-local-fw-4api-250rps | legitimate_goodput_per_second | 190.9561065013597 | 190.87631792971703 | 191.27030614877532 |
| scale-local-fw-4api-250rps | legitimate_p95_ms | 53.477258 | 53.334758 | 53.512637 |
| scale-local-fw-4api-250rps | legitimate_p99_ms | 53.90664 | 53.768215 | 53.932928 |
| scale-local-fw-4api-250rps | http_429 | 0 | 0 | 0 |
| scale-local-fw-4api-250rps | http_5xx | 1762 | 1753 | 1765 |
| scale-local-fw-4api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-local-fw-4api-250rps | backend_overload | 1762 | 1753 | 1765 |
| scale-redis-fw-1api-50rps | legitimate_goodput_per_second | 49.943592689232275 | 49.94357647920743 | 49.94372770777384 |
| scale-redis-fw-1api-50rps | legitimate_p95_ms | 54.690471 | 54.533418 | 54.754052 |
| scale-redis-fw-1api-50rps | legitimate_p99_ms | 55.024859 | 54.976738 | 55.119178 |
| scale-redis-fw-1api-50rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-1api-50rps | http_5xx | 0 | 0 | 0 |
| scale-redis-fw-1api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-redis-fw-1api-50rps | backend_overload | 0 | 0 | 0 |
| scale-redis-fw-1api-180rps | legitimate_goodput_per_second | 179.70412644650915 | 179.64573497910166 | 179.70585343966903 |
| scale-redis-fw-1api-180rps | legitimate_p95_ms | 53.879848 | 53.829066 | 54.075433 |
| scale-redis-fw-1api-180rps | legitimate_p99_ms | 54.283383 | 54.263053 | 54.583034 |
| scale-redis-fw-1api-180rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-1api-180rps | http_5xx | 0 | 0 | 2 |
| scale-redis-fw-1api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-redis-fw-1api-180rps | backend_overload | 0 | 0 | 2 |
| scale-redis-fw-1api-250rps | legitimate_goodput_per_second | 190.62029221623297 | 190.5429019100064 | 190.74870064436868 |
| scale-redis-fw-1api-250rps | legitimate_p95_ms | 53.800917 | 53.574131 | 53.830031 |
| scale-redis-fw-1api-250rps | legitimate_p99_ms | 54.172424 | 53.94829 | 54.297175 |
| scale-redis-fw-1api-250rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-1api-250rps | http_5xx | 1772 | 1768 | 1775 |
| scale-redis-fw-1api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-redis-fw-1api-250rps | backend_overload | 1772 | 1768 | 1775 |
| scale-redis-fw-2api-50rps | legitimate_goodput_per_second | 49.943266151053 | 49.943024888996746 | 49.944868067703226 |
| scale-redis-fw-2api-50rps | legitimate_p95_ms | 54.760563 | 54.748683 | 54.78878 |
| scale-redis-fw-2api-50rps | legitimate_p99_ms | 55.154535 | 55.126783 | 55.20819 |
| scale-redis-fw-2api-50rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-2api-50rps | http_5xx | 0 | 0 | 0 |
| scale-redis-fw-2api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-redis-fw-2api-50rps | backend_overload | 0 | 0 | 0 |
| scale-redis-fw-2api-180rps | legitimate_goodput_per_second | 179.70762453051373 | 179.70499814397883 | 179.7104051823508 |
| scale-redis-fw-2api-180rps | legitimate_p95_ms | 53.960961 | 53.888285 | 54.187851 |
| scale-redis-fw-2api-180rps | legitimate_p99_ms | 54.412178 | 54.28527 | 54.733524 |
| scale-redis-fw-2api-180rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-2api-180rps | http_5xx | 0 | 0 | 0 |
| scale-redis-fw-2api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-redis-fw-2api-180rps | backend_overload | 0 | 0 | 0 |
| scale-redis-fw-2api-250rps | legitimate_goodput_per_second | 190.61148655625303 | 190.21440013848738 | 190.78650510310635 |
| scale-redis-fw-2api-250rps | legitimate_p95_ms | 54.075881 | 53.953837 | 54.286898 |
| scale-redis-fw-2api-250rps | legitimate_p99_ms | 54.561461 | 54.414937 | 54.883999 |
| scale-redis-fw-2api-250rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-2api-250rps | http_5xx | 1772 | 1767 | 1784 |
| scale-redis-fw-2api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-redis-fw-2api-250rps | backend_overload | 1772 | 1767 | 1784 |
| scale-redis-fw-4api-50rps | legitimate_goodput_per_second | 49.941836676574795 | 49.94087427646611 | 49.942693732197334 |
| scale-redis-fw-4api-50rps | legitimate_p95_ms | 54.78335 | 54.488528 | 54.82661 |
| scale-redis-fw-4api-50rps | legitimate_p99_ms | 55.179925 | 54.969735 | 55.346221 |
| scale-redis-fw-4api-50rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-4api-50rps | http_5xx | 0 | 0 | 0 |
| scale-redis-fw-4api-50rps | backend_arrivals | 1500 | 1500 | 1500 |
| scale-redis-fw-4api-50rps | backend_overload | 0 | 0 | 0 |
| scale-redis-fw-4api-180rps | legitimate_goodput_per_second | 179.67767684649021 | 179.64096778401353 | 179.67773222393822 |
| scale-redis-fw-4api-180rps | legitimate_p95_ms | 54.048787 | 53.931394 | 54.395004 |
| scale-redis-fw-4api-180rps | legitimate_p99_ms | 54.621118 | 54.433125 | 55.143394 |
| scale-redis-fw-4api-180rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-4api-180rps | http_5xx | 1 | 1 | 2 |
| scale-redis-fw-4api-180rps | backend_arrivals | 5400 | 5400 | 5400 |
| scale-redis-fw-4api-180rps | backend_overload | 1 | 1 | 2 |
| scale-redis-fw-4api-250rps | legitimate_goodput_per_second | 190.71471924591873 | 190.61179504885283 | 190.7490780798803 |
| scale-redis-fw-4api-250rps | legitimate_p95_ms | 53.749409 | 53.602152 | 53.871077 |
| scale-redis-fw-4api-250rps | legitimate_p99_ms | 54.203996 | 54.045706 | 54.329318 |
| scale-redis-fw-4api-250rps | http_429 | 0 | 0 | 0 |
| scale-redis-fw-4api-250rps | http_5xx | 1769 | 1768 | 1772 |
| scale-redis-fw-4api-250rps | backend_arrivals | 7500 | 7500 | 7500 |
| scale-redis-fw-4api-250rps | backend_overload | 1769 | 1768 | 1772 |
| outage-open-healthy | legitimate_goodput_per_second | 19.971697150657786 | 19.971657163487187 | 19.997031466008444 |
| outage-open-healthy | legitimate_p95_ms | 54.182922 | 54.141003 | 54.357637 |
| outage-open-healthy | legitimate_p99_ms | 54.537649 | 54.530447 | 54.727225 |
| outage-open-healthy | http_429 | 1783 | 1780 | 1796 |
| outage-open-healthy | http_5xx | 0 | 0 | 0 |
| outage-open-healthy | backend_arrivals | 1217 | 1204 | 1220 |
| outage-open-healthy | backend_overload | 0 | 0 | 0 |
| outage-open-outage | legitimate_goodput_per_second | 19.930823073406028 | 19.930536077944335 | 19.963614953288623 |
| outage-open-outage | legitimate_p95_ms | 153.015416 | 152.898142 | 153.039116 |
| outage-open-outage | legitimate_p99_ms | 153.882719 | 153.863291 | 153.913592 |
| outage-open-outage | http_429 | 1635 | 1631 | 1636 |
| outage-open-outage | http_5xx | 7 | 6 | 7 |
| outage-open-outage | backend_arrivals | 1365 | 1364 | 1369 |
| outage-open-outage | backend_overload | 7 | 6 | 7 |
| outage-closed-healthy | legitimate_goodput_per_second | 19.996891601848716 | 19.971790763583087 | 19.99705371076163 |
| outage-closed-healthy | legitimate_p95_ms | 54.080204 | 54.050344 | 54.198134 |
| outage-closed-healthy | legitimate_p99_ms | 54.516331 | 54.494123 | 54.611465 |
| outage-closed-healthy | http_429 | 1782 | 1780 | 1799 |
| outage-closed-healthy | http_5xx | 0 | 0 | 0 |
| outage-closed-healthy | backend_arrivals | 1218 | 1201 | 1220 |
| outage-closed-healthy | backend_overload | 0 | 0 | 0 |
| outage-closed-outage | legitimate_goodput_per_second | 18.40714379455887 | 18.349038172592632 | 18.40758582329114 |
| outage-closed-outage | legitimate_p95_ms | 54.228171 | 54.027894 | 54.230425 |
| outage-closed-outage | legitimate_p99_ms | 54.801364 | 54.632862 | 54.880742 |
| outage-closed-outage | http_429 | 1637 | 1631 | 1637 |
| outage-closed-outage | http_5xx | 238 | 238 | 244 |
| outage-closed-outage | backend_arrivals | 1130 | 1130 | 1130 |
| outage-closed-outage | backend_overload | 5 | 5 | 5 |

| Run / repetition | Tooling | Oracle | Flags |
| --- | --- | --- | --- |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | not_applicable | none |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | not_applicable | none |
| custom-repeat-1 / 1 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 1 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 1 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | not_applicable | none |
| custom-repeat-1 / 1 | usable | no_violation_observed_within_trace | none |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | no_violation_observed_within_trace | none |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | not_applicable | none |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | not_applicable | none |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 1 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 1 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | inconclusive | none |
| custom-repeat-1 / 1 | usable | not_applicable | none |
| t07-20261020T075256-288143-open-healthy / 1 | usable | inconclusive | none |
| t07-20261020T075345-288143-open-outage / 1 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |
| t07-20261020T075436-294052-closed-healthy / 1 | usable | inconclusive | none |
| t07-20261020T075524-294052-closed-outage / 1 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | not_applicable | none |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | not_applicable | none |
| custom-repeat-1 / 2 | usable | not_applicable | none |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 2 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 2 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | not_applicable | none |
| custom-repeat-1 / 2 | usable | no_violation_observed_within_trace | none |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | no_violation_observed_within_trace | none |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | not_applicable | none |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | not_applicable | none |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 2 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | inconclusive | none |
| custom-repeat-1 / 2 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 2 | usable | not_applicable | none |
| t07-20261020T112046-236025-open-healthy / 2 | usable | inconclusive | none |
| t07-20261020T112132-236025-open-outage / 2 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |
| t07-20261020T112533-253473-closed-healthy / 2 | usable | inconclusive | none |
| t07-20261020T112621-253473-closed-outage / 2 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | not_applicable | none |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | not_applicable | none |
| custom-repeat-1 / 3 | usable | not_applicable | none |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 3 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 3 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | not_applicable | none |
| custom-repeat-1 / 3 | usable | no_violation_observed_within_trace | none |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | no_violation_observed_within_trace | none |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | not_applicable | none |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | not_applicable | none |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |
| custom-repeat-1 / 3 | usable | no_violation_observed_within_trace | http_5xx_observed |
| custom-repeat-1 / 3 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 3 | usable | not_applicable | http_5xx_observed |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | inconclusive | none |
| custom-repeat-1 / 3 | usable | not_applicable | none |
| t07-20261020T124723-561421-open-healthy / 3 | usable | inconclusive | none |
| t07-20261020T124810-561421-open-outage / 3 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |
| t07-20261020T124859-567265-closed-healthy / 3 | usable | inconclusive | none |
| t07-20261020T124947-567265-closed-outage / 3 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |
| custom-repeat-1 / 3 | usable | inconclusive | http_5xx_observed |

This exporter writes CSV/Markdown only. Use the separate offline plot-calibration.py for selected pilot charts; no runtime dependency was added.
