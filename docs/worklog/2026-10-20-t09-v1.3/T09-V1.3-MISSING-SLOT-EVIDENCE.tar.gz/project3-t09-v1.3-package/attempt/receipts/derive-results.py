import copy, hashlib, json
from pathlib import Path
base=Path('/tmp/project3-t09-v1.2-results-20261020/manifest.json')
out=Path('/tmp/project3-t09-v1.3-results-20261020/derived-results-manifest.json')
protocol=Path('/home/khanhson2005/projects/project3-rate-limiter/docs/experiments/protocol-v1.2/manifest.json')
raw=Path('/tmp/project3-t09-v13-0291/artifacts/protocol-v1.3/p1-129-scale-redis-fw-1api-250rps-r3/custom-repeat-1')
quality=Path('/tmp/project3-t09-v1.3-results-20261020/coordinator-quality-check.json')
original_sha=hashlib.sha256(base.read_bytes()).hexdigest()
assert original_sha=='c0f16fb5349ae4653514ff4f7f79d7047ca72453e644bc8f40a1676ac2eebf64'
m=json.loads(base.read_text())
assert len(m['runs'])==137
assert m['missing_planned_run_ids']==['p1-129-scale-redis-fw-1api-250rps-r3']
q=json.loads(quality.read_text())
assert q['valid'] is True and q['reasons']==[]
full=json.loads(protocol.read_text())
plan=[r for r in full['runs'] if r['planned_run_id']=='p1-129-scale-redis-fw-1api-250rps-r3']
assert len(plan)==1
assert json.loads((raw/'load/summary.json').read_text())['generator_dropped']==0
checksums={}
for p in sorted(raw.rglob('*')):
    if p.is_file(): checksums[str(p.relative_to(raw))]=hashlib.sha256(p.read_bytes()).hexdigest()
entry={
    'cell':plan[0]['cell'], 'config_fingerprint':q['config_fingerprint'],
    'group':plan[0]['group'], 'image_fingerprint':q['image_fingerprint'],
    'path':str(raw), 'planned_run_id':plan[0]['planned_run_id'],
    'raw_checksums':checksums, 'repetition':str(plan[0]['repetition']),
}
assert entry['repetition']=='3'
old_runs=copy.deepcopy(m['runs'])
m['runs'].append(entry)
assert m['runs'][:137]==old_runs
m['missing_planned_run_ids']=[]
locked=json.loads(protocol.read_text())
m['clock_tolerance_ms']=locked['clock_tolerance_ms']
m['continuation_addendum']={
    'path':'docs/experiments/protocol-v1.3/protocol.md',
    'revision':'e0f02867343fbea93d399b9a17229ed813867452',
    'planned_run_id':entry['planned_run_id'],
    'v1_3_attempt_receipt_sha256':hashlib.sha256(Path('/tmp/project3-t09-v1.3-results-20261020/attempt.json').read_bytes()).hexdigest(),
    'checker_output_sha256':hashlib.sha256(quality.read_bytes()).hexdigest(),
    'source_manifest_sha256':original_sha,
}
out.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'derived_manifest':str(out),'source_manifest_sha256':original_sha,'derived_manifest_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'run_count':len(m['runs']),'missing':m['missing_planned_run_ids'],'new_run_checksums':len(checksums)},indent=2))
