import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/tmp/project3-t09-v13-0291')
manifest_path = Path('/home/khanhson2005/projects/project3-rate-limiter/docs/experiments/protocol-v1.2/manifest.json')
manifest = json.loads(manifest_path.read_text())
run_id = 'p1-129-scale-redis-fw-1api-250rps-r3'
rows = [row for row in manifest['runs'] if row['planned_run_id'] == run_id]
assert len(rows) == 1
row = rows[0]
assert row['source_revision'] == '0291a80fb404fea0eafee8c3431acc3631bb423e'
assert row['config']['workload'] == {
    'legitimate_clients': 5, 'duration_s': 30, 'max_inflight': 200,
    'timeout_ms': 2000, 'max_schedule_lag_ms': 100, 'profile': 'normal',
    'rps': 250, 'legitimate_rps': 250, 'abusive_rps': 0,
}
assert row['config']['policy'] == {
    'mode': 'redis', 'algorithm': 'fixed-window', 'fail_policy': 'closed',
    'limit': 1000, 'window_ms': 1000, 'capacity': 1000,
    'rate_per_sec': 1000, 'state_reset': True,
}
assert row['config']['topology'] == {
    'api_instances': 1, 'backend_capacity': 10, 'backend_service_ms': 50,
}
assert row['command'] == [
    'bash', 'scripts/research-pilot.sh', '--output',
    'artifacts/protocol-v1.2/p1-129-scale-redis-fw-1api-250rps-r3',
    '--case', 'custom', '--repetitions', '1', '--analyze', '--host-port', '18080',
]
assert row['environment'] == {
    'CUSTOM_MODE': 'redis', 'CUSTOM_ALGORITHM': 'fixed-window',
    'CUSTOM_INSTANCES': '1', 'CUSTOM_PROFILE': 'normal', 'CUSTOM_RPS': '250',
    'CUSTOM_LEGIT_RPS': '250', 'CUSTOM_DURATION': '30', 'CUSTOM_LIMIT': '1000',
    'CUSTOM_WINDOW_MS': '1000', 'CUSTOM_CAPACITY': '1000', 'CUSTOM_RATE': '1000',
    'CUSTOM_BACKEND_CAPACITY': '10', 'CUSTOM_BACKEND_SERVICE_MS': '50',
    'CUSTOM_FAIL_POLICY': 'closed', 'CUSTOM_BURST_START': '2',
    'CUSTOM_BURST_DURATION': '2', 'CUSTOM_BURST_RPS': '200', 'LAB_HOST_PORT': '18080',
}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == row['source_revision']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip() == ''
manifest_sha = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
assert manifest_sha == '8fdee2bee729665327fd0d5e03b89a4fd4d10bfed4dc872a82bd5ddf649acb1e'
raw_root = 'artifacts/protocol-v1.3/p1-129-scale-redis-fw-1api-250rps-r3'
assert not (root / raw_root).exists()
assert row['result_path'].endswith('/custom-repeat-1')
argv = list(row['command'])
argv[argv.index('--output') + 1] = raw_root
record = {
    'event': 'attempt_started', 'planned_run_id': run_id,
    'protocol_addendum_commit': 'e0f02867343fbea93d399b9a17229ed813867452',
    'manifest_path': str(manifest_path), 'manifest_sha256': manifest_sha,
    'source_revision': row['source_revision'], 'source_status_porcelain': '',
    'config': row['config'], 'environment': row['environment'],
    'command': argv, 'run_dir': str(root / raw_root / 'custom-repeat-1'),
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
external = Path('/tmp/project3-t09-v1.3-results-20261020')
(external / 'attempt.json').write_text(json.dumps(record, indent=2) + '\n')
env = os.environ.copy()
env.update(row['environment'])
with (external / 'runner.log').open('w') as log:
    result = subprocess.run(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
record['event'] = 'attempt_finished'
record['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['runner_exit_code'] = result.returncode
record['raw_output_exists'] = (root / raw_root / 'custom-repeat-1').is_dir()
(external / 'attempt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'planned_run_id': run_id, 'runner_exit_code': result.returncode,
                  'raw_output_exists': record['raw_output_exists'],
                  'run_dir': record['run_dir']}))
sys.exit(result.returncode)
