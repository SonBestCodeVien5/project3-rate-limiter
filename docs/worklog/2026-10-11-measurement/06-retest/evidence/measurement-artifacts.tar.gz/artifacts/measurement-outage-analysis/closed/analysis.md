# Analysis: outage-closed

Pilot observation; not a locked research conclusion.

Policy: `redis` / `fixed-window`; oracle: **inconclusive**.

Requests: 1000; sent: 1000; generator drops: 0.

Observed violations: 0. See `analysis.json` for scope and evidence.

## Redis outage

Availability uses legitimate successes divided by legitimate requests sent in each send-time phase.

- before: 61/61 legitimate successful/sent; availability 1.0.
- pausing: 8/8 legitimate successful/sent; availability 1.0.
- outage: 0/40 legitimate successful/sent; availability 0.0.
- unpausing: 2/8 legitimate successful/sent; availability 0.25.
- after: 82/83 legitimate successful/sent; availability 0.9879518072289156.

Stable recovery: 3000 ms (observed).

Boundary windows, missing decisions and unknown prior state limit correctness claims. TB uses its own token semantics; FW quota is not applied to TB.
