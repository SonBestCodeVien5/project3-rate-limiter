from __future__ import annotations
import json, os, pathlib, re, subprocess, sys, threading, time

OUT = pathlib.Path(__file__).resolve().parent
CTL = OUT / "tickctl"
ARM = OUT / "guard-arm.json"
DISARM = OUT / "guard-disarm.json"
GUARD_RESULT = OUT / "guard-result.json"
GUARD_LOG = OUT / "guard.log"
ACTIVE_SECONDS_RAW = 35.0
GUARD_SECONDS_RAW = 37.0


def command(args, timeout=3):
    try:
        p = subprocess.run(args, text=True, capture_output=True, timeout=timeout)
        return {"argv": args, "returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    except subprocess.TimeoutExpired as e:
        return {"argv": args, "timeout_seconds": timeout, "stdout": str(e.stdout or ""), "stderr": str(e.stderr or "")}


def raw_ns():
    return time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)


def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2) + "\n")


def set_tick(expected, target, timeout=4):
    argv = [str(CTL), "set-tick", str(expected), str(target)]
    if os.geteuid() != 0:
        argv = ["sudo", "-n", *argv]
    return command(argv, timeout=timeout)


def parse_status(stdout):
    keep = {"Server", "Poll interval", "Offset", "Packet count", "Frequency", "Jitter", "Delay", "Stratum"}
    out = {}
    for line in stdout.splitlines():
        m = re.match(r"\s*([^:]+):\s*(.*?)\s*$", line)
        if m and m.group(1) in keep:
            out[m.group(1)] = m.group(2)
    return out


def watchdog(helper, arm, disarm, result):
    start_wait = raw_ns()
    while not arm.exists() and not disarm.exists() and raw_ns() - start_wait < 15_000_000_000:
        time.sleep(0.05)
    if disarm.exists() or not arm.exists():
        write_json(result, {"result": "disarmed_before_set_or_no_arm", "raw_ns": raw_ns()})
        return 0
    arm_data = json.loads(arm.read_text())
    deadline = arm_data["arm_raw_ns"] + int(GUARD_SECONDS_RAW * 1e9)
    while not disarm.exists() and raw_ns() < deadline:
        time.sleep(0.05)
    if disarm.exists():
        write_json(result, {"result": "main_path_disarmed_after_verified_restore", "raw_ns": raw_ns()})
        return 0
    q = command([str(helper), "query"], timeout=2)
    if q["returncode"] != 0 or "tick_us=10000" not in q["stdout"]:
        state = "guard_found_not_active_or_query_failed"
        set_result = None
    else:
        argv = [str(helper), "set-tick", "10000", "9167"]
        if os.geteuid() != 0:
            argv = ["sudo", "-n", *argv]
        set_result = command(argv, timeout=3)
        state = "guard_restore_verified" if set_result["returncode"] == 0 else "GUARD_RESTORE_FAILED"
    verify = command([str(helper), "query"], timeout=2)
    write_json(result, {"result": state, "guard_deadline_raw_ns": deadline, "guard_action_raw_ns": raw_ns(), "pre_restore_query": q, "restore_command": set_result, "verification_query": verify})
    return 0 if state in ("guard_restore_verified", "guard_found_not_active_or_query_failed") else 10


def execute():
    user_hz = os.sysconf("SC_CLK_TCK")
    pre_query = command([str(CTL), "query"])
    if user_hz != 100 or pre_query["returncode"] != 0 or "tick_us=9167" not in pre_query["stdout"]:
        write_json(OUT / "aborted-precondition.json", {"user_hz": user_hz, "query": pre_query, "reason": "expected USER_HZ=100 and tick=9167 before any mutation"})
        print("ABORTED before setter: precondition mismatch")
        return 20
    prior_status = command(["timedatectl", "timesync-status"], timeout=3)
    prior_service = command(["systemctl", "show", "systemd-timesyncd.service", "-p", "ActiveState", "-p", "SubState", "-p", "MainPID"], timeout=3)
    metadata = {"revision": "dd307a6a5775cb122ffa207ec5591de8d134a569", "start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "user_hz": user_hz, "pre_query": pre_query, "prior_timesync_status": prior_status, "prior_timesync_status_parsed": parse_status(prior_status.get("stdout", "")), "prior_timesync_service": prior_service, "active_target_seconds_raw": ACTIVE_SECONDS_RAW, "watchdog_restore_deadline_seconds_raw_from_arm": GUARD_SECONDS_RAW, "step_threshold_ms": 5}
    write_json(OUT / "metadata-before.json", metadata)

    # Detached guard starts before arm/set; it restores only the exact authorized 10000→9167 transition.
    with GUARD_LOG.open("w") as log:
        guard = subprocess.Popen([sys.executable, str(pathlib.Path(__file__).resolve()), "--watchdog", str(CTL), str(ARM), str(DISARM), str(GUARD_RESULT)], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    time.sleep(0.05)
    if guard.poll() is not None:
        write_json(OUT / "guard-launch-failure.json", {"returncode": guard.returncode, "raw_ns": raw_ns()})
        print("ABORTED before setter: independent rollback guard failed to stay alive")
        return 23
    write_json(ARM, {"arm_raw_ns": raw_ns(), "original_tick_us": 9167, "target_tick_us": 10000, "guard_pid": guard.pid})

    setter = None
    active_start = None
    samples = []
    status_rows = []
    stop_status = threading.Event()
    status_errors = []

    def status_sampler():
        next_poll = raw_ns()
        while not stop_status.is_set():
            before = raw_ns()
            row = command(["timedatectl", "timesync-status"], timeout=1.5)
            after = raw_ns()
            status_rows.append({"before_raw_ns": before, "after_raw_ns": after, "returncode": row.get("returncode"), "timeout_seconds": row.get("timeout_seconds"), "parsed": parse_status(row.get("stdout", "")), "stderr": row.get("stderr", "")})
            next_poll += 1_000_000_000
            while not stop_status.is_set() and raw_ns() < next_poll:
                time.sleep(0.02)

    worker = threading.Thread(target=status_sampler, name="bounded-timesync-readonly", daemon=True)
    active_error = None
    try:
        setter = set_tick(9167, 10000, timeout=4)
        if setter["returncode"] != 0:
            active_error = "setter_failed_or_post-set_check_failed"
            return_code = 21
        else:
            active_start = raw_ns()
            worker.start()
            target = active_start + int(ACTIVE_SECONDS_RAW * 1e9)
            while raw_ns() < target:
                m1 = time.monotonic_ns(); r1 = raw_ns(); b1 = time.clock_gettime_ns(time.CLOCK_BOOTTIME); wall = time.time_ns(); b2 = time.clock_gettime_ns(time.CLOCK_BOOTTIME); r2 = raw_ns(); m2 = time.monotonic_ns()
                samples.append({"wall_ns": wall, "monotonic_ns": (m1 + m2) // 2, "monotonic_raw_ns": (r1 + r2) // 2, "boottime_ns": (b1 + b2) // 2, "sample_span_mono_ns": m2 - m1})
                time.sleep(0.05)
            return_code = 0
    except BaseException as e:
        active_error = type(e).__name__ + ": " + str(e)
        return_code = 22
    finally:
        stop_status.set()
        if worker.is_alive():
            worker.join(timeout=2)
        before_restore_raw = raw_ns()
        q = command([str(CTL), "query"], timeout=2)
        restore_command = None
        if q["returncode"] == 0 and "tick_us=10000" in q["stdout"]:
            restore_command = set_tick(10000, 9167, timeout=4)
        elif q["returncode"] == 0 and "tick_us=9167" in q["stdout"]:
            restore_command = {"returncode": 0, "stdout": "already restored to original 9167 by watchdog or no transition", "stderr": ""}
        verify = command([str(CTL), "query"], timeout=2)
        restored = verify["returncode"] == 0 and "tick_us=9167" in verify["stdout"]
        restore_info = {"before_restore_raw_ns": before_restore_raw, "pre_restore_query": q, "restore_command": restore_command, "verification_query": verify, "restored_verified": restored, "verify_raw_ns": raw_ns()}
        write_json(OUT / "restore.json", restore_info)
        if restored:
            write_json(DISARM, {"verified_original_tick": 9167, "raw_ns": raw_ns()})
        if worker.is_alive():
            worker.join(timeout=1)
        try:
            guard.wait(timeout=4)
        except subprocess.TimeoutExpired:
            active_error = (active_error or "") + "; watchdog did not exit after disarm"
        metadata.update({"setter": setter, "active_error": active_error, "active_start_raw_ns": active_start, "restore": restore_info, "status_sample_count": len(status_rows), "clock_sample_count": len(samples), "guard_pid": guard.pid, "guard_returncode": guard.poll(), "guard_result": json.loads(GUARD_RESULT.read_text()) if GUARD_RESULT.exists() else None})
        write_json(OUT / "metadata-after.json", metadata)
        (OUT / "clock-samples.jsonl").write_text("".join(json.dumps(x, separators=(",", ":")) + "\n" for x in samples))
        (OUT / "timesync-status-samples.jsonl").write_text("".join(json.dumps(x, separators=(",", ":")) + "\n" for x in status_rows))
        if samples:
            first, last = samples[0], samples[-1]
            dm = (last["monotonic_ns"] - first["monotonic_ns"]) / 1e9
            dr = (last["monotonic_raw_ns"] - first["monotonic_raw_ns"]) / 1e9
            dw = (last["wall_ns"] - first["wall_ns"]) / 1e9
            steps = []
            for i, (a, b) in enumerate(zip(samples, samples[1:]), 1):
                resid = (b["wall_ns"] - a["wall_ns"]) - (b["monotonic_ns"] - a["monotonic_ns"])
                if abs(resid) > 5_000_000:
                    steps.append({"sample_index": i, "elapsed_raw_seconds": (b["monotonic_raw_ns"] - first["monotonic_raw_ns"]) / 1e9, "wall_minus_monotonic_delta_ms": resid / 1e6})
            summary = {"clock_sample_count": len(samples), "timesync_status_sample_count": len(status_rows), "elapsed_monotonic_seconds": dm, "elapsed_raw_seconds": dr, "elapsed_boottime_seconds": (last["boottime_ns"] - first["boottime_ns"]) / 1e9, "elapsed_wall_seconds": dw, "monotonic_over_raw_ratio": dm / dr if dr else None, "max_sample_span_us": max(x["sample_span_mono_ns"] for x in samples) / 1e3, "wall_steps_over_5ms_vs_monotonic": steps, "timesync_status_changes": []}
            last_status = None
            for row in status_rows:
                parsed = row["parsed"]
                key = (parsed.get("Packet count"), parsed.get("Offset"), parsed.get("Poll interval"))
                if key != last_status:
                    summary["timesync_status_changes"].append({"elapsed_raw_seconds": (row["before_raw_ns"] - first["monotonic_raw_ns"]) / 1e9, "parsed": parsed, "returncode": row.get("returncode"), "timeout_seconds": row.get("timeout_seconds")})
                    last_status = key
            write_json(OUT / "summary.json", summary)
        metadata["post_restore_timesync_status"] = command(["timedatectl", "timesync-status"], timeout=3)
        metadata["post_restore_query"] = command([str(CTL), "query"], timeout=2)
        write_json(OUT / "metadata-after.json", metadata)
        report = {"setter_returncode": setter.get("returncode") if setter else None, "active_duration_raw_seconds": ((before_restore_raw - active_start) / 1e9) if active_start else 0, "clock_samples": len(samples), "timesync_status_samples": len(status_rows), "restored_verified": restored, "final_tick_query": metadata["post_restore_query"], "guard_returncode": metadata["guard_returncode"], "guard_result": metadata["guard_result"], "active_error": active_error}
        print("TRIAL_COMPLETE " + json.dumps(report, sort_keys=True), flush=True)
        if not restored or metadata["guard_returncode"] not in (0, None):
            print("URGENT: restore or guard verification failed", file=sys.stderr)
            return_code = 90
    return return_code


def validate():
    if os.sysconf("SC_CLK_TCK") != 100:
        print("validation_failed USER_HZ != 100")
        return 1
    q = command([str(CTL), "query"])
    if q["returncode"] != 0 or "tick_us=9167" not in q["stdout"]:
        print("validation_failed unexpected pre-state: " + json.dumps(q))
        return 2
    print("validation_ok: helper struct=208, query modes=0, USER_HZ=100, tick=9167; no setter invoked")
    print(q["stdout"].strip())
    print("watchdog-validation_ok: target transition limited to 10000→9167 after 37 RAW seconds; no setter invoked")
    return 0

if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "--validate":
        raise SystemExit(validate())
    if len(sys.argv) == 6 and sys.argv[1] == "--watchdog":
        raise SystemExit(watchdog(pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3]), pathlib.Path(sys.argv[4]), pathlib.Path(sys.argv[5])))
    if len(sys.argv) == 2 and sys.argv[1] == "--execute":
        raise SystemExit(execute())
    raise SystemExit("usage: trial.py --validate | --execute | --watchdog HELPER ARM DISARM RESULT")
