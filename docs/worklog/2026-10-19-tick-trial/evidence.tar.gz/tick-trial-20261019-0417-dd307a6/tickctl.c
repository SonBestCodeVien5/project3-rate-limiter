#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/timex.h>

static int query(struct timex *tx) {
    memset(tx, 0, sizeof(*tx));
    tx->modes = 0;
    return adjtimex(tx);
}

static void print_result(const char *op, int state, int err, const struct timex *tx) {
    struct timespec raw = {0};
    clock_gettime(CLOCK_MONOTONIC_RAW, &raw);
    printf("operation=%s return_state=%d errno=%d modes=%u tick_us=%ld freq_scaled_ppm=%ld freq_ppm=%.9f realtime_offset_us=%ld monotonic_raw_ns=%lld\n",
           op, state, err, tx->modes, tx->tick, tx->freq, tx->freq / 65536.0, tx->offset,
           (long long)raw.tv_sec * 1000000000LL + raw.tv_nsec);
}

int main(int argc, char **argv) {
    if (sizeof(struct timex) != 208) {
        fprintf(stderr, "unexpected_struct_size=%zu\n", sizeof(struct timex));
        return 2;
    }
    if (argc == 2 && strcmp(argv[1], "query") == 0) {
        struct timex tx;
        errno = 0;
        int state = query(&tx), err = state < 0 ? errno : 0;
        print_result("query_modes0", state, err, &tx);
        return state < 0 ? 1 : 0;
    }
    if (argc == 4 && strcmp(argv[1], "set-tick") == 0) {
        char *end1, *end2;
        long expected = strtol(argv[2], &end1, 10), target = strtol(argv[3], &end2, 10);
        if (*end1 || *end2 || !((expected == 9167 && target == 10000) || (expected == 10000 && target == 9167))) {
            fprintf(stderr, "refusing_unapproved_tick_transition\n");
            return 2;
        }
        struct timex before;
        errno = 0;
        int before_state = query(&before), before_err = before_state < 0 ? errno : 0;
        print_result("pre_set_query_modes0", before_state, before_err, &before);
        if (before_state < 0 || before.tick != expected) {
            fprintf(stderr, "refusing_unexpected_pre_set_state expected_tick=%ld actual_tick=%ld\n", expected, before.tick);
            return 3;
        }
        struct timex tx;
        memset(&tx, 0, sizeof(tx));
        tx.modes = ADJ_TICK;
        tx.tick = target;
        errno = 0;
        int state = adjtimex(&tx), err = state < 0 ? errno : 0;
        print_result("set_only_ADJ_TICK", state, err, &tx);
        if (state < 0) return 4;
        struct timex after;
        errno = 0;
        int after_state = query(&after), after_err = after_state < 0 ? errno : 0;
        print_result("post_set_query_modes0", after_state, after_err, &after);
        if (after_state < 0 || after.tick != target) {
            fprintf(stderr, "post_set_verification_failed expected_tick=%ld actual_tick=%ld\n", target, after.tick);
            return 5;
        }
        return 0;
    }
    fprintf(stderr, "usage: tickctl query | set-tick 9167 10000 | set-tick 10000 9167\n");
    return 2;
}
