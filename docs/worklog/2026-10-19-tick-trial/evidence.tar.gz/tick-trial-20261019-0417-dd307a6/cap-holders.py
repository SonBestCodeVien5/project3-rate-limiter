import os, pathlib
mask = 1 << 25
for d in pathlib.Path("/proc").iterdir():
    if not d.name.isdigit(): continue
    try:
        status = (d / "status").read_text()
        vals = {}
        for line in status.splitlines():
            if line.startswith(("CapEff:", "PPid:")): vals[line.split(":",1)[0]] = line.split(":",1)[1].strip()
        if int(vals.get("CapEff", "0"), 16) & mask:
            comm = (d / "comm").read_text().strip()
            exe = os.path.basename(os.readlink(d / "exe"))
            print(f"pid={d.name} comm={comm} ppid={vals.get("PPid","?")} exe={exe}")
    except (OSError, ValueError): pass
