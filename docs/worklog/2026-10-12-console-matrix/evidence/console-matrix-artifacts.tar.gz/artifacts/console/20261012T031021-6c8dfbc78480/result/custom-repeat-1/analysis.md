# Analysis: custom-repeat-1

Pilot observation; not a locked research conclusion.

Policy: `none` / `fixed-window`; oracle: **not_applicable**.

Requests: 100; sent: 100; generator drops: 0.

Observed violations: 0. See `analysis.json` for scope and evidence.

Boundary windows, missing decisions and unknown prior state limit correctness claims. TB uses its own token semantics; FW quota is not applied to TB.
