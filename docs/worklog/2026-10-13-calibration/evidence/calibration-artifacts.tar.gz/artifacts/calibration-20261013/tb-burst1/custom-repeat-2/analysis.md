# Analysis: custom-repeat-2

Pilot observation; not a locked research conclusion.

Policy: `local` / `token-bucket`; oracle: **no_violation_observed_within_trace**.

Requests: 820; sent: 820; generator drops: 0.

Observed violations: 0. See `analysis.json` for scope and evidence.

Boundary windows, missing decisions and unknown prior state limit correctness claims. TB uses its own token semantics; FW quota is not applied to TB.
