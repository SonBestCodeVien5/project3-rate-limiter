#include <stddef.h>
#include <stdio.h>
#include <linux/timex.h>

int main(void) {
    printf("header=linux/timex.h\n");
    printf("sizeof(struct __kernel_timex)=%zu\n", sizeof(struct __kernel_timex));
    printf("offsetof(modes)=%zu sizeof(modes)=%zu\n",
           offsetof(struct __kernel_timex, modes), sizeof(((struct __kernel_timex *)0)->modes));
    printf("offsetof(tick)=%zu sizeof(tick)=%zu\n",
           offsetof(struct __kernel_timex, tick), sizeof(((struct __kernel_timex *)0)->tick));
    return 0;
}
