import json, pathlib, subprocess, os
out=pathlib.Path(__file__).resolve().parent
checks={}
def run(args,timeout=4):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
        return {'argv':args,'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    except Exception as e:return {'argv':args,'error':type(e).__name__+': '+str(e)}
checks['identity']=run(['uname','-a'])
checks['machine']=run(['uname','-m'])
checks['compiler']=run(['gcc','--version'])
k=run(['uname','-r']); rel=k.get('stdout','').strip(); checks['kernel_release']=k
checks['headers']={}
for p in [f'/usr/src/linux-headers-{rel}',f'/lib/modules/{rel}/build',f'/usr/include/linux/timex.h']:
    q=pathlib.Path(p)
    checks['headers'][p]={'exists':q.exists(),'resolved':str(q.resolve()) if q.exists() else None}
    if q.is_file():
        try:
            lines=q.read_text(errors='replace').splitlines()
            hits=[(i+1,x.strip()) for i,x in enumerate(lines) if '__kernel_timex' in x or 'struct __kernel_timex' in x]
            checks['headers'][p]['matching_declarations']=hits[:20]
        except Exception as e: checks['headers'][p]['read_error']=str(e)
# Only consider a build-tree UAPI header whose directory is named for exact uname -r.
base=pathlib.Path(f'/usr/src/linux-headers-{rel}')
inc=base/'include/uapi'
src='/home/khanhson2005/projects/project3-rate-limiter/artifacts/tick-trace-layout-20261019-1148/layout_probe.c'
if inc.exists() and (inc/'linux/timex.h').exists():
    checks['compile']=run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-I'+str(inc),src,'-o',str(out/'layout_probe')],8)
    if checks['compile'].get('rc')==0: checks['layout_output']=run([str(out/'layout_probe')],2)
else:
    checks['compile']={'skipped':'No exact-release /usr/src/linux-headers-<uname -r>/include/uapi/linux/timex.h; no fallback header compiled.'}
(out/'native-check.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
