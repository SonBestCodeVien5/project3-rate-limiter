import pathlib,re,subprocess,json
base=pathlib.Path('/usr/src/linux-headers-6.18.54.1-microsoft-standard-WSL2')
files=[base/'include/linux/timex.h',base/'include/linux/timekeeping.h']
out={}
for p in files:
 rows=[]
 try:
  for i,line in enumerate(p.read_text(errors='replace').splitlines(),1):
   if re.search(r'do_adjtimex|__kernel_timex|include.*timex',line): rows.append({'line':i,'text':line.strip()[:300]})
  out[str(p)]={'exists':p.exists(),'matches':rows}
 except Exception as e:out[str(p)]={'exists':p.exists(),'error':type(e).__name__+': '+str(e)}
p=str(base/'include/linux/timex.h')
q=subprocess.run(['dpkg-query','-S',p],capture_output=True,text=True,timeout=3)
out['package_owner']={'rc':q.returncode,'stdout':q.stdout.strip(),'stderr':q.stderr.strip()}
print(json.dumps(out,indent=2))
