import json,pathlib,subprocess
r=subprocess.run(['uname','-r'],capture_output=True,text=True,timeout=2).stdout.strip()
b=pathlib.Path('/usr/src')/('linux-headers-'+r)
paths=[b/'include/uapi/linux/timex.h',b/'include/linux/timex.h',b/'include/generated/uapi/linux/timex.h',b/'include/generated/utsrelease.h',b/'include/config/kernel.release',b/'arch/x86/include/uapi/asm/bitsperlong.h',b/'arch/x86/include/generated/uapi/asm/unistd_64.h',b/'Makefile',b/'source']
out=[]
for p in paths:
 item={'path':str(p),'exists':p.exists(),'is_symlink':p.is_symlink()}
 if p.exists():
  try:item['resolved']=str(p.resolve())
  except OSError:pass
  if p.is_file() and p.name in ('utsrelease.h','kernel.release','Makefile'):
   try:item['content']=p.read_text(errors='replace')[:300]
   except OSError as e:item['error']=str(e)
 out.append(item)
print(json.dumps({'release':r,'matching_paths':out},indent=2))
