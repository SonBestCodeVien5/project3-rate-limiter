# Study artifact report

Measured artifacts only. No winner or final research conclusion is inferred.

Business problem → pain point → business impact → technical requirement → solution → experiment → evaluation → future development must be supplied in the research report.

Tooling validity, correctness oracle and research claims are separate. FW inconclusive/partial windows do not invalidate a run by themselves. Errors/overload may be intended outcomes; flags require interpretation against the locked protocol.

Cell statistics are median/min/max of separate run metrics. A median of run p95/p99 is not a pooled percentile. No aggregation is exported for incomplete, incompatible or invalid-evidence cells.

Client clock check compares wall-clock sent−scheduled with monotonic schedule lag; it cannot diagnose server clock steps. Tolerance (ms): 5

| Cell | Runs / expected | Aggregation |
| --- | --- | --- |
| open-healthy | 1 / 1 | invalid_run_evidence |
| open-outage | 1 / 1 | invalid_run_evidence |
| closed-healthy | 1 / 1 | invalid_run_evidence |
| closed-outage | 1 / 1 | invalid_run_evidence |

| Cell | Metric | Median of runs | Run min | Run max |
| --- | --- | --- | --- | --- |

| Run / repetition | Tooling | Oracle | Flags |
| --- | --- | --- | --- |
| None / 1 | invalid | missing | malformed_evidence:AttributeError |
| None / 1 | invalid | missing | malformed_evidence:AttributeError |
| None / 1 | invalid | missing | malformed_evidence:AttributeError |
| None / 1 | invalid | missing | malformed_evidence:AttributeError |

This exporter writes CSV/Markdown only. Use the separate offline plot-calibration.py for selected pilot charts; no runtime dependency was added.
