# Study artifact report

Measured artifacts only. No winner or final research conclusion is inferred.

Business problem → pain point → business impact → technical requirement → solution → experiment → evaluation → future development must be supplied in the research report.

Tooling validity, correctness oracle and research claims are separate. FW inconclusive/partial windows do not invalidate a run by themselves. Errors/overload may be intended outcomes; flags require interpretation against the locked protocol.

Cell statistics are median/min/max of separate run metrics. A median of run p95/p99 is not a pooled percentile. No aggregation is exported for incomplete, incompatible or invalid-evidence cells.

Client clock check compares wall-clock sent−scheduled with monotonic schedule lag; it cannot diagnose server clock steps. Tolerance (ms): 5

| Cell | Runs / expected | Aggregation |
| --- | --- | --- |
| open-healthy | 1 / 1 | complete_same_config |
| open-outage | 1 / 1 | complete_same_config |
| closed-healthy | 1 / 1 | complete_same_config |
| closed-outage | 1 / 1 | complete_same_config |

| Cell | Metric | Median of runs | Run min | Run max |
| --- | --- | --- | --- | --- |
| open-healthy | legitimate_goodput_per_second | 19.997026281549154 | 19.997026281549154 | 19.997026281549154 |
| open-healthy | legitimate_p95_ms | 54.603207 | 54.603207 | 54.603207 |
| open-healthy | legitimate_p99_ms | 55.969826 | 55.969826 | 55.969826 |
| open-healthy | http_429 | 1800 | 1800 | 1800 |
| open-healthy | http_5xx | 0 | 0 | 0 |
| open-healthy | backend_arrivals | 1200 | 1200 | 1200 |
| open-healthy | backend_overload | 0 | 0 | 0 |
| open-outage | legitimate_goodput_per_second | 19.99689100670044 | 19.99689100670044 | 19.99689100670044 |
| open-outage | legitimate_p95_ms | 153.129045 | 153.129045 | 153.129045 |
| open-outage | legitimate_p99_ms | 153.852485 | 153.852485 | 153.852485 |
| open-outage | http_429 | 1600 | 1600 | 1600 |
| open-outage | http_5xx | 7 | 7 | 7 |
| open-outage | backend_arrivals | 1400 | 1400 | 1400 |
| open-outage | backend_overload | 7 | 7 | 7 |
| closed-healthy | legitimate_goodput_per_second | 19.996594449987303 | 19.996594449987303 | 19.996594449987303 |
| closed-healthy | legitimate_p95_ms | 55.051472 | 55.051472 | 55.051472 |
| closed-healthy | legitimate_p99_ms | 55.880021 | 55.880021 | 55.880021 |
| closed-healthy | http_429 | 1780 | 1780 | 1780 |
| closed-healthy | http_5xx | 0 | 0 | 0 |
| closed-healthy | backend_arrivals | 1220 | 1220 | 1220 |
| closed-healthy | backend_overload | 0 | 0 | 0 |
| closed-outage | legitimate_goodput_per_second | 18.063281794312324 | 18.063281794312324 | 18.063281794312324 |
| closed-outage | legitimate_p95_ms | 55.550001 | 55.550001 | 55.550001 |
| closed-outage | legitimate_p99_ms | 58.847245 | 58.847245 | 58.847245 |
| closed-outage | http_429 | 1595 | 1595 | 1595 |
| closed-outage | http_5xx | 288 | 288 | 288 |
| closed-outage | backend_arrivals | 1122 | 1122 | 1122 |
| closed-outage | backend_overload | 5 | 5 | 5 |

| Run / repetition | Tooling | Oracle | Flags |
| --- | --- | --- | --- |
| t07-20261019T124613-6293-open-healthy / 1 | usable | inconclusive | none |
| t07-20261019T124704-6293-open-outage / 1 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |
| t07-20261019T124754-6293-closed-healthy / 1 | usable | inconclusive | none |
| t07-20261019T124848-6293-closed-outage / 1 | usable | inconclusive | http_5xx_observed;limiter_errors_observed |

This exporter writes CSV/Markdown only. Use the separate offline plot-calibration.py for selected pilot charts; no runtime dependency was added.
